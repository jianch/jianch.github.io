function chanlocs = loadavgchanlocs(path,people,type,handles)
i = 1;
j = 1;
filename = eval(changepath(path));

try
[f,fid] = eeg_load_scan4_avg(filename);
%chantotal = readlocs(['\standard-10-5-cap385.elp']);
load([pwd,'\ERP_tool\chanlocs\chanlocsposition.mat']);
labeltotal = lower({chantotal.labels});
for s = 1:length(f.electloc)
    chanlocs(1,s).labels = char(f.electloc(1,s).lab(find(f.electloc(1,s).lab~=0))');
    poi = strmatch(lower(chanlocs(1,s).labels),labeltotal,'exact');
    if length(poi)
        chanlocs(1,s).theta = chantotal(1,poi).theta;
        chanlocs(1,s).radius = chantotal(1,poi).radius;
        chanlocs(1,s).X = chantotal(1,poi).X;
        chanlocs(1,s).Y = chantotal(1,poi).Y;
        chanlocs(1,s).Z = chantotal(1,poi).Z;
        chanlocs(1,s).sph_theta = chantotal(1,poi).sph_theta;
        chanlocs(1,s).sph_phi = chantotal(1,poi).sph_phi;
        chanlocs(1,s).sph_radius = chantotal(1,poi).sph_radius;
        chanlocs(1,s).type = [];
        chanlocs(1,s).urchan = s;
    end
    chanlocs(1,s).ref    = '';
end
INFO = get(handles,'String');
INFO{length(INFO)+1} = ['�ɹ�����缫,�缫��ĿΪ',num2str(length(chanlocs))];
set(handles,'String',INFO);
drawnow

catch
INFO = get(handles,'String');
INFO{length(INFO)+1} = ['�缫�ļ�����ʧ�ܣ�����avg�ļ�·���Լ�standard-10-5-cap385.elp�ļ��Ƿ����'];
set(handles,'String',INFO);
drawnow
end
end