function varargout = pop_figure(varargin)
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @pop_figure_OpeningFcn, ...
                   'gui_OutputFcn',  @pop_figure_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end

function pop_figure_OpeningFcn(hObject, eventdata, handles, varargin)
handles.output = hObject;
guidata(hObject, handles);
toolhandles = guidata(ERP_tool);
set(handles.figure1,'UserData',toolhandles);

function varargout = pop_figure_OutputFcn(hObject, eventdata, handles) 
varargout{1} = handles.output;


%% ������
function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu2.
function popupmenu2_Callback(hObject, eventdata, handles)
xuanzekuai = get(hObject,'String');
choi       = get(hObject,'Value');
fig        = get(handles.pushbutton12,'UserData');
%% ���� ������
set(handles.edit5,'String',xuanzekuai{choi});
%% ���� ��ʾ��Χ
xlim       = get(fig.axesmain(choi),'XLim');
ylim       = get(fig.axesmain(choi),'YLim');
set(handles.edit4,'String',num2str([xlim,ylim]));
%% ���� x������
set(handles.edit6,'String',get(fig.axes(get(handles.popupmenu2,'Value')).xlabels,'String'));
%% ���� y������
set(handles.edit7,'String',get(fig.axes(get(handles.popupmenu2,'Value')).ylabels,'String'));
%% ���� ѡ����
set(handles.popupmenu3,'String',fig.axes(choi).String,'Value',1);
%% ����������λ��
set(handles.edit28,'String',num2str(fig.axes(choi).xycross));



% --- Executes during object creation, after setting all properties.
function popupmenu2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit4_Callback(hObject, eventdata, handles)
%% ��ȡ������Ϣ
fig = get(handles.pushbutton12,'UserData');
kuaichoi = get(handles.popupmenu2,'Value');
dispsize = str2num(get(hObject,'String'));
h = fig.axesmain(get(handles.popupmenu2,'Value'));
xtick = get(h,'XTick');
ytick = get(h,'YTick');
xcha = xtick(2)-xtick(1);
xtick_new = round(dispsize(1):xcha:dispsize(2));
while length(xtick_new)<2
    xcha = xcha/2;
    xtick_new = round(dispsize(1):xcha:dispsize(2));
end
xtick_newlabel = num2strcell(xtick_new);
set(fig.axesmain(kuaichoi),'XTick',xtick_new,'XTickLabel',xtick_newlabel);
ycha = ytick(2)-ytick(1);
ytick_new = dispsize(3):ycha:dispsize(4);
while length(ytick_new)<2
    ycha = ycha/2;
    ytick_new = dispsize(3):ycha:dispsize(4);
end
ytick_newlabel = num2strcell(ytick_new);
set(fig.axesmain(kuaichoi),'YTick',ytick_new,'YTickLabel',ytick_newlabel);
axes(h);
axis(dispsize);
if ~isempty(fig.axes(kuaichoi).lines)
    fig.axes(kuaichoi).legends = legend(fig.axes(kuaichoi).lines,fig.axes(kuaichoi).String,...
        'FontSize',str2num(get(handles.edit16,'String')));
end
delete(fig.axes(kuaichoi).Xs);
delete(fig.axes(kuaichoi).Ys);
[fig.axes(kuaichoi).Xs,fig.axes(kuaichoi).Ys] = axesset(fig.axesmain(kuaichoi),fig.axes(kuaichoi).xycross);
set(handles.pushbutton12,'UserData',fig);
if ~isempty(fig.axes(kuaichoi).legends)
    uistack(fig.axes(kuaichoi).legends , 'top');
end
% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit5_Callback(hObject, eventdata, handles)
fig = get(handles.pushbutton12,'UserData');
set(fig.axes(get(handles.popupmenu2,'Value')).titles,'String',get(hObject,'String'));
xuanzekuai = get(handles.popupmenu2,'String');
xuanzekuai{get(handles.popupmenu2,'Value')} = get(hObject,'String');
set(handles.popupmenu2,'String',xuanzekuai);


% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit6_Callback(hObject, eventdata, handles)
fig = get(handles.pushbutton12,'UserData');
set(fig.axes(get(handles.popupmenu2,'Value')).xlabels,'String',get(hObject,'String'));


% --- Executes during object creation, after setting all properties.
function edit6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit7_Callback(hObject, eventdata, handles)
fig = get(handles.pushbutton12,'UserData');
set(fig.axes(get(handles.popupmenu2,'Value')).ylabels,'String',get(hObject,'String'));

% --- Executes during object creation, after setting all properties.
function edit7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
position1 = get(handles.uipanel1,'Position');
set(handles.uipanel1,'Visible','off');
set(handles.uipanel5,'Position',position1)
set(handles.uipanel5,'Visible','on');

fig = get(handles.pushbutton12,'UserData');
if ~isempty(fig)
    h = fig.axesmain(get(handles.popupmenu2,'Value'));
    xtick = get(h,'XTick');
    xticklabel = get(h,'XTickLabel');
    ytick = get(h,'YTick');
    yticklabel = get(h,'YTickLabel');
    set(handles.edit11,'String',num2str(xtick(2)-xtick(1)));
    set(handles.edit12,'String',num2str(ytick(2)-ytick(1)));
    set(handles.edit13,'String',xticklabel);
    set(handles.edit14,'String',yticklabel);
    h1 = fig.axes(get(handles.popupmenu2,'Value')).legends;
    if ~isempty(h1)
        set(handles.edit16,'String',num2str(get(h1,'FontSize')));
    end
    switch get(h,'YDir')
        case 'reverse'
            set(handles.edit17,'String','on');
        otherwise
            set(handles.edit17,'String','off');
    end
end
% --- Executes on selection change in popupmenu3.
function popupmenu3_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenu3 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu3


% --- Executes during object creation, after setting all properties.
function popupmenu3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit8_Callback(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit8 as text
%        str2double(get(hObject,'String')) returns contents of edit8 as a double


% --- Executes during object creation, after setting all properties.
function edit8_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in listbox1.
function listbox1_Callback(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns listbox1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox1


% --- Executes during object creation, after setting all properties.
function listbox1_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in listbox2.
function listbox2_Callback(hObject, eventdata, handles)
% hObject    handle to listbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns listbox2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox2


% --- Executes during object creation, after setting all properties.
function listbox2_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in listbox3.
function listbox3_Callback(hObject, eventdata, handles)
% hObject    handle to listbox3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns listbox3 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox3


% --- Executes during object creation, after setting all properties.
function listbox3_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
position3 = get(handles.uipanel3,'Position');
set(handles.uipanel3,'Visible','off');
set(handles.uipanel6,'Position',position3)
set(handles.uipanel6,'Visible','on');

fig = get(handles.pushbutton12,'UserData');
kuaichoi = get(handles.popupmenu2,'Value');
linechoi = get(handles.popupmenu3,'Value');
if length(fig.axes(kuaichoi).lines(linechoi))
    set(handles.edit20,'String',num2str(get(fig.axes(kuaichoi).lines(linechoi),'LineWidth')));
    set(handles.edit21,'String',num2str(get(fig.axes(kuaichoi).lines(linechoi),'Color')));
    set(handles.edit22,'String',get(fig.axes(kuaichoi).lines(linechoi),'LineStyle'));
end


function edit10_Callback(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit10 as text
%        str2double(get(hObject,'String')) returns contents of edit10 as a double


% --- Executes during object creation, after setting all properties.
function edit10_CreateFcn(hObject, eventdata, handles)
set(hObject,'String','');

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
str = totalswrites(handles.listbox1,handles.listbox2,handles.listbox3);
s = get(handles.edit10,'String');
s = [s,str];
set(handles.edit10,'String',s);

% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
global people
people = get(handles.listbox1,'String');
type   = get(handles.listbox2,'String');
chanlocsname = get(handles.listbox3,'String');
toolhandle = get(handles.figure1,'UserData');
data = get(toolhandle.togglebutton2,'UserData');
info = get(toolhandle.togglebutton1,'UserData');
t = info.time(1):(round(1000/info.rate)):info.time(2); 
INFOhandle = toolhandle.edit4;
s = get(handles.edit10,'String');
fig = get(handles.pushbutton12,'UserData');
if ~isempty(s)
    if length(regexp(s,'ttest'))
        wave = ttest(people,type,data,chanlocsname,INFOhandle,s);
    else
        wave = totalsreads(people,type,data,chanlocsname,INFOhandle,s);
    end
    set(fig.axesmain(get(handles.popupmenu2,'Value')),'NextPlot','add');
    axeschoi = get(handles.popupmenu2,'Value');
    linenext  = length(fig.axes(axeschoi).lines)+1;
    fig.axes(axeschoi).data{linenext} = wave;
    colororder = eval(get(handles.edit26,'String'));
    linetypeorder = eval(get(handles.edit27,'String'));
    a = mod(ceil((linenext-0.5)/length(linetypeorder))-1,size(colororder,1))+1;
    b = mod(linenext-1,length(linetypeorder))+1;
    linewidth = str2num(get(handles.edit20,'String'));
    %% ����
    m = ceil(str2num(get(handles.edit18,'String')));
    n = str2num(get(handles.edit19,'String'));
    dis_o=[1:(m-1),m,(fliplr(1:(m-1)))];
    dis=n.^dis_o/sum(n.^dis_o);
    wave_juan = conv(dis,wave);
    wave_new = wave_juan(m:(length(wave)+m-1));
    fig.axes(axeschoi).lines(linenext) = plot(fig.axesmain(axeschoi),t,wave_new,...
        'Color',colororder(a,:),'LineStyle',linetypeorder{b},...
        'LineWidth',linewidth);
    
    %% ������
    defaultlinename = get(handles.edit24,'String');
    linename        = get(handles.edit8,'String');
    if ~iscell(defaultlinename)    defaultlinename = cellstr(defaultlinename); end
    if strmatch('default',defaultlinename)
        if strmatch('default',linename)
            linename_now = ['Line ',num2str(linenext)];
        else
            linename_now = linename;
        end
    else
        linename_now = defaultlinename{mod(linenext-1,length(defaultlinename))+1};
    end
    %% ��������
    xuanzexian = get(handles.popupmenu3,'String');
    if ~iscell(xuanzexian)    xuanzexian = cellstr(xuanzexian); end
    xuanzexian{linenext} = linename_now;
    fig.axes(axeschoi).String = xuanzexian;
    if ~iscell(fig.axes(axeschoi).String)  fig.axes(axeschoi).String=cellstr(fig.axes(axeschoi).String),end
    set(handles.popupmenu3,'String',xuanzexian,'Value',linenext);
    %legendname = get(fig.axes(axeschoi).legends,'String');
    %legendname{linenext} = linename_now;
    %set(fig.axes(axeschoi).legends,'String',legendname);
    fig.axes(axeschoi).legends = legend(fig.axes(axeschoi).lines,xuanzexian,...
        'FontSize',str2num(get(handles.edit16,'String')));
    uistack(fig.axes(axeschoi).legends , 'top');
    %% ������
    set(handles.pushbutton12,'UserData',fig);
end
% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
%% ��ȡ��������
blockchoi = get(handles.popupmenu2,'Value');
linestr   = get(handles.popupmenu3,'String');
linechoi  = get(handles.popupmenu3,'Value');
fig       = get(handles.pushbutton12,'UserData');
if ~length(strmatch('Empty',linestr(linechoi)))
    %% ɾ�� ѡ����
    if length(linestr)==1
        set(handles.popupmenu3,'String','Empty','Value',1);
        fig.axes(blockchoi).String = {'Empty'};
    else
        set(handles.popupmenu3,'String',linestr(1:end~=linechoi),'Value',1);
        fig.axes(blockchoi).String = fig.axes(blockchoi).String(1:end~=linechoi);
    end
    %% ɾ�� ����
    delete(fig.axes(blockchoi).lines(linechoi));
    fig.axes(blockchoi).lines = fig.axes(blockchoi).lines(1:end~=linechoi);
    %% ɾ�� ��ע
    if length(linestr)==1
        fig.axes(blockchoi).legends = [];
        legend(fig.axesmain(blockchoi),'off');
    else
        fig.axes(blockchoi).legends = legend(fig.axes(blockchoi).lines,fig.axes(blockchoi).String);
    end
    %% ���� fig
    set(handles.pushbutton12,'UserData',fig);
end
    

% --- Executes on button press in pushbutton8.
function pushbutton8_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function edit11_Callback(hObject, eventdata, handles)
%% ��ȡ������Ϣ
fig = get(handles.pushbutton12,'UserData');
kuaichoi = get(handles.popupmenu2,'Value');
%% ��ȡ���ֵ��Сֵ
dispsize = str2num(get(handles.edit4,'String'));
%% ����X���ʶ
jiange = str2num(get(hObject,'String'));
biao = round(dispsize(1):jiange:dispsize(2));
biaolabel = num2strcell(biao);
set(fig.axesmain(kuaichoi),'XTick',biao,'XTickLabel',biaolabel);
delete(fig.axes(kuaichoi).Xs);
delete(fig.axes(kuaichoi).Ys);
figure(fig.main);
[fig.axes(kuaichoi).Xs,fig.axes(kuaichoi).Ys] = axesset(fig.axesmain(kuaichoi),fig.axes(kuaichoi).xycross);
if ~isempty(fig.axes(kuaichoi).legends)
    uistack(fig.axes(kuaichoi).legends , 'top');
end
set(handles.edit13,'String',biaolabel);
set(handles.pushbutton12,'UserData',fig);   




% --- Executes during object creation, after setting all properties.
function edit11_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit12_Callback(hObject, eventdata, handles)
%% ��ȡ������Ϣ
fig = get(handles.pushbutton12,'UserData');
kuaichoi = get(handles.popupmenu2,'Value');
%% ��ȡ���ֵ��Сֵ
dispsize = str2num(get(handles.edit4,'String'));
%% ����Y���ʶ
jiange = str2num(get(hObject,'String'));
biao = dispsize(3):jiange:dispsize(4);
biaolabel = num2strcell(biao);
set(fig.axesmain(kuaichoi),'YTick',biao,'YTickLabel',biaolabel);
delete(fig.axes(kuaichoi).Xs);
delete(fig.axes(kuaichoi).Ys);
figure(fig.main);
[fig.axes(kuaichoi).Xs,fig.axes(kuaichoi).Ys] = axesset(fig.axesmain(kuaichoi),fig.axes(kuaichoi).xycross);
if ~isempty(fig.axes(kuaichoi).legends)
    uistack(fig.axes(kuaichoi).legends , 'top');
end
set(handles.edit14,'String',biaolabel);
set(handles.pushbutton12,'UserData',fig);   

% --- Executes during object creation, after setting all properties.
function edit12_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit13_Callback(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
kuaichoi = get(handles.popupmenu2,'Value');
fig = get(handles.pushbutton12,'UserData');
labels = get(hObject,'String');
set(fig.axesmain(kuaichoi),'XTickLabel',labels);
delete(fig.axes(kuaichoi).Xs);
delete(fig.axes(kuaichoi).Ys);
figure(fig.main);
[fig.axes(kuaichoi).Xs,fig.axes(kuaichoi).Ys] = axesset(fig.axesmain(kuaichoi),fig.axes(kuaichoi).xycross);
if ~isempty(fig.axes(kuaichoi).legends)
    uistack(fig.axes(kuaichoi).legends , 'top');
end
set(handles.pushbutton12,'UserData',fig);  
% Hints: get(hObject,'String') returns contents of edit13 as text
%        str2double(get(hObject,'String')) returns contents of edit13 as a double


% --- Executes during object creation, after setting all properties.
function edit13_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit14_Callback(hObject, eventdata, handles)
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
kuaichoi = get(handles.popupmenu2,'Value');
fig = get(handles.pushbutton12,'UserData');
labels = get(hObject,'String');
set(fig.axesmain(kuaichoi),'YTickLabel',labels);
delete(fig.axes(kuaichoi).Xs);
delete(fig.axes(kuaichoi).Ys);
figure(fig.main);
[fig.axes(kuaichoi).Xs,fig.axes(kuaichoi).Ys] = axesset(fig.axesmain(kuaichoi),fig.axes(kuaichoi).xycross);
if ~isempty(fig.axes(kuaichoi).legends)
    uistack(fig.axes(kuaichoi).legends , 'top');
end
set(handles.pushbutton12,'UserData',fig);
% Hints: get(hObject,'String') returns contents of edit14 as text
%        str2double(get(hObject,'String')) returns contents of edit14 as a double


% --- Executes during object creation, after setting all properties.
function edit14_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit16_Callback(hObject, eventdata, handles)
fig = get(handles.pushbutton12,'UserData');
kuaichoi = get(handles.popupmenu2,'Value');
fontsize = str2num(get(hObject,'String'));
set(fig.axes(kuaichoi).legends,'FontSize',fontsize);


% --- Executes during object creation, after setting all properties.
function edit16_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit17_Callback(hObject, eventdata, handles)
fig = get(handles.pushbutton12,'UserData');
kuaichoi = get(handles.popupmenu2,'Value');
switch get(hObject,'String')
    case 'on'
        set(fig.axesmain(kuaichoi),'YDir','reverse');
    case 'off'
        set(fig.axesmain(kuaichoi),'YDir','normal');
    otherwise
end
delete(fig.axes(kuaichoi).Xs);
delete(fig.axes(kuaichoi).Ys);
figure(fig.main);
[fig.axes(kuaichoi).Xs,fig.axes(kuaichoi).Ys] = axesset(fig.axesmain(kuaichoi),fig.axes(kuaichoi).xycross);
if ~isempty(fig.axes(kuaichoi).legends)
    uistack(fig.axes(kuaichoi).legends , 'top');
end
set(handles.pushbutton12,'UserData',fig);


% --- Executes during object creation, after setting all properties.
function edit17_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit17 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton9.
function pushbutton9_Callback(hObject, eventdata, handles)
set(handles.uipanel5,'Visible','off');
set(handles.uipanel1,'Visible','on');



function edit18_Callback(hObject, eventdata, handles)
fig = get(handles.pushbutton12,'UserData');
if str2num(get(hObject,'String'))>0|str2num(get(handles.edit19,'String'))>=1
    a = ceil(str2num(get(hObject,'String')));
    b = str2num(get(handles.edit19,'String'));
    set(hObject,'String',num2str(a));
    dis_o=[1:(a-1),a,(fliplr(1:(a-1)))];
    x_xian = (-a+1):(a-1);
    dis=b.^dis_o/sum(b.^dis_o);
    bar(handles.axes1,x_xian,dis);
    for i = 1:length(fig.axes)
        linenum = length(fig.axes(i).lines);
        for j = 1 : linenum
            wave = fig.axes(i).data{j};
            wave_juan = conv(dis,wave);
            wave_new = wave_juan(a:(length(wave)+a-1));
            set(fig.axes(i).lines(j),'YData',wave_new);
        end
    end
end


% --- Executes during object creation, after setting all properties.
function edit18_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit18 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit19_Callback(hObject, eventdata, handles)
fig = get(handles.pushbutton12,'UserData');
if str2num(get(handles.edit18,'String'))>0|str2num(get(hObject,'String'))>=1
    a = ceil(str2num(get(handles.edit18,'String')));
    b = str2num(get(hObject,'String'));
    set(handles.edit18,'String',num2str(a));
    dis_o=[1:(a-1),a,(fliplr(1:(a-1)))];
    x_xian = (-a+1):(a-1);
    dis=b.^dis_o/sum(b.^dis_o);
    bar(handles.axes1,x_xian,dis);
    for i = 1:length(fig.axes)
        linenum = length(fig.axes(i).lines);
        for j = 1 : linenum
            wave = fig.axes(i).data{j};
            wave_juan = conv(dis,wave);
            wave_new = wave_juan(a:(length(wave)+a-1));
            set(fig.axes(i).lines(j),'YData',wave_new);
        end
    end
end

% --- Executes during object creation, after setting all properties.
function edit19_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit19 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit20_Callback(hObject, eventdata, handles)
fig = get(handles.pushbutton12,'UserData');
kuaichoi = get(handles.popupmenu2,'Value');
linechoi = get(handles.popupmenu3,'Value');
xiankuan = str2num(get(hObject,'String'));
if length(fig.axes(kuaichoi).lines(linechoi))
    set(fig.axes(kuaichoi).lines(linechoi),'LineWidth',xiankuan);
end


% --- Executes during object creation, after setting all properties.
function edit20_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit20 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit21_Callback(hObject, eventdata, handles)
fig = get(handles.pushbutton12,'UserData');
kuaichoi = get(handles.popupmenu2,'Value');
linechoi = get(handles.popupmenu3,'Value');
yanse = str2num(get(hObject,'String'));
if length(fig.axes(kuaichoi).lines(linechoi))
    set(fig.axes(kuaichoi).lines(linechoi),'Color',yanse);
end


% --- Executes during object creation, after setting all properties.
function edit21_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit21 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit22_Callback(hObject, eventdata, handles)
fig = get(handles.pushbutton12,'UserData');
kuaichoi = get(handles.popupmenu2,'Value');
linechoi = get(handles.popupmenu3,'Value');
linetype = get(hObject,'String');
if length(fig.axes(kuaichoi).lines(linechoi))
    set(fig.axes(kuaichoi).lines(linechoi),'LineStyle',linetype);
end

% --- Executes during object creation, after setting all properties.
function edit22_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit22 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton10.
function pushbutton10_Callback(hObject, eventdata, handles)
set(handles.uipanel6,'Visible','off');
set(handles.uipanel3,'Visible','on');



function edit23_Callback(hObject, eventdata, handles)
% hObject    handle to edit23 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit23 as text
%        str2double(get(hObject,'String')) returns contents of edit23 as a double


% --- Executes during object creation, after setting all properties.
function edit23_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit23 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit24_Callback(hObject, eventdata, handles)
% hObject    handle to edit24 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit24 as text
%        str2double(get(hObject,'String')) returns contents of edit24 as a double


% --- Executes during object creation, after setting all properties.
function edit24_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit24 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit25_Callback(hObject, eventdata, handles)
% hObject    handle to edit25 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit25 as text
%        str2double(get(hObject,'String')) returns contents of edit25 as a double


% --- Executes during object creation, after setting all properties.
function edit25_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit25 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton12.
function pushbutton12_Callback(hObject, eventdata, handles)
fenkuai = str2num(get(handles.edit2,'String'));
tool_handles = get(handles.figure1,'UserData');
people = get(tool_handles.edit2,'String');
if ~iscell(people)
    people = cellstr(people);
end
people{end+1} = 'AVG';
set(handles.listbox1,'String',people);
set(handles.listbox2,'String',get(tool_handles.edit3,'String'));
chanlocs = get(tool_handles.togglebutton3,'UserData');
chanlocsname = {chanlocs.labels};
set(handles.listbox3,'String',chanlocsname);
if length(fenkuai)==2
    %% ����Ƿ�򿪹�figure
    if ~isempty(get(handles.pushbutton12,'UserData'))
        %% ��λ
        set(handles.edit8,'String','\default');
        set(handles.popupmenu3,'String',{'Empty'},'Value',1);
        set(handles.edit10,'String','');
        set(handles.edit28,'String','0 0');
        %% ɾ��fig
        set(handles.pushbutton12,'UserData',[]);
    end
    fig.main = figure();
    set(fig.main,'DefaultAxesFontSize',str2num(get(handles.edit25,'String')));
    set(fig.main,'DefaultAxesFontName','Arial');
    info = get(tool_handles.togglebutton1,'UserData');
    display.size = [info.time(1),info.time(2),-10,10];
    display.x.tick=round(display.size(1):200:display.size(2));
    display.x.ticklabel=num2strcell(display.x.tick);
    display.y.tick=round(display.size(3):2:display.size(4));
    display.y.ticklabel=num2strcell(display.y.tick);
    for i = 1:(fenkuai(1)*fenkuai(2))
        if strmatch('default',get(handles.edit23,'String'))
            s{i} = ['figure ',num2str(i)];
        else
            try
                kuainame = get(handles.edit23,'String');
                if ~iscell(kuainame)
                    kuainame = cellstr(kuainame);
                end
                s{i} = kuainame{mod(i-1,length(kuainame))+1};
            catch
                writeinfo(tool_handles.edit4,'��Ĭ�����Ƹ�ʽ����');
                break;
            end
        end
        fig.axesmain(i) = subplot(fenkuai(1),fenkuai(2),i);
        set(fig.axesmain(i),'NextPlot','add');
        axis(display.size);
        set(gca,'xtick',display.x.tick);
        set(gca,'XTickLabel',display.x.ticklabel);
        set(gca,'ytick',display.y.tick);
        set(gca,'YTickLabel',display.y.ticklabel);
        set(gca,'Ydir','reverse');
        [fig.axes(i).Xs,fig.axes(i).Ys] = axesset(fig.axesmain(i),[0,0]);
        fig.axes(i).xlabels = xlabel(fig.axesmain(i),'Time(ms)','Color',[0.01,0.01,0.01],'Visible','on');
        fig.axes(i).ylabels = ylabel(fig.axesmain(i),'Amplitude(��V)','Color',[0.01,0.01,0.01],'Visible','on');
        fig.axes(i).titles = title(fig.axesmain(i),s{i},'Visible','on');
        fig.axes(i).lines = [];
        fig.axes(i).legends = [];
        fig.axes(i).String = {'Empty'};
        fig.axes(i).data = {};
        fig.axes(i).xycross = [0,0];

    end
    set(handles.popupmenu2,'String',s,'Value',1);
    set(handles.edit5,'String',s{1});
    set(handles.edit4,'String',num2str(display.size));
    set(hObject,'UserData',fig);
else
    writeinfo(tool_handles.edit4,'���ڷֿ��������������֣�����֮���ÿո�򶺺Ÿ���������������ֹ������');
end      
                
            

% --- Executes on button press in pushbutton13.
function pushbutton13_Callback(hObject, eventdata, handles)
set(handles.uipanel1,'Visible','off');
set(handles.uipanel3,'Visible','off');
position1 = get(handles.uipanel1,'Position');
position3 = get(handles.uipanel3,'Position');
position7 = [position3(1),position3(2),position3(3),position1(4)+position3(4)+0.2];
set(handles.uipanel7,'Position',position7,'Visible','on');

function edit26_Callback(hObject, eventdata, handles)
% hObject    handle to edit26 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit26 as text
%        str2double(get(hObject,'String')) returns contents of edit26 as a double


% --- Executes during object creation, after setting all properties.
function edit26_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit26 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit27_Callback(hObject, eventdata, handles)
% hObject    handle to edit27 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit27 as text
%        str2double(get(hObject,'String')) returns contents of edit27 as a double


% --- Executes during object creation, after setting all properties.
function edit27_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit27 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton11.
function pushbutton11_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.uipanel7,'Visible','off');
set([handles.uipanel1,handles.uipanel3],'Visible','on');



function edit28_Callback(hObject, eventdata, handles)
%% ��ȡ������Ϣ
fig = get(handles.pushbutton12,'UserData');
kuaichoi = get(handles.popupmenu2,'Value');
fig.axes(kuaichoi).xycross = str2num(get(hObject,'String'));
delete(fig.axes(kuaichoi).Xs);
delete(fig.axes(kuaichoi).Ys);
figure(fig.main);
[fig.axes(kuaichoi).Xs,fig.axes(kuaichoi).Ys] = axesset(fig.axesmain(kuaichoi),fig.axes(kuaichoi).xycross);
if ~isempty(fig.axes(kuaichoi).legends)
    uistack(fig.axes(kuaichoi).legends , 'top');
end
set(handles.pushbutton12,'UserData',fig);   

% --- Executes during object creation, after setting all properties.
function edit28_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit28 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton14.


% --- Executes on button press in pushbutton15.
function pushbutton15_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% --- Executes on button press in pushbutton14.

fig = get(handles.pushbutton12,'UserData');
axessize = str2num(get(handles.edit4,'String'));
bkcolor = get(fig.main,'Color');
turntype = get(handles.edit17,'String');
[filename,pathname,filterindex] = uiputfile(...
    {'*.tif','TIFF��ʽ';...
    '*.bmp','BMP��ʽ'},...
    'Print as');
j = 0;
for i = 1:length(fig.axesmain)
    axes(fig.axes(i).Xs);
    j = j+1;
    linepoi(j) = line([axessize(1),axessize(1)],[-0.02,0.02],'Color','k','LineWidth',1.5);
    set(fig.axes(i).Xs,'YLim',[0,1]);
    axes(fig.axes(i).Ys);
    switch turntype
        case 'on'
            j = j+1;
            linepoi(j) = line([-0.01,0.01],[axessize(4),axessize(4)],'Color','k','LineWidth',1.5);
            set(fig.axes(i).Ys,'XLim',[0,1]);
        case 'off'
            j = j+1;
            linepoi(j) = line([-0.01,0.01],[axessize(3),axessize(3)],'Color','k','LineWidth',1.5);
            set(fig.axes(i).Ys,'XLim',[0,1]);
        otherwise
    end
end
set(fig.main,'Color',[1,1,1]);

pstion = get(fig.main,'PaperPosition');
pstion(3) = str2num(get(handles.edit29,'String'));
pstion(4) = str2num(get(handles.edit31,'String'));
set(fig.main,'PaperPosition',pstion);
PPI = get(handles.edit30,'String');

switch filterindex
    case 1
        print(fig.main,['-r',PPI],'-dtiff',[pathname,filename]);
    otherwise
        print(fig.main,['-r',PPI],'-dbmp',[pathname,filename]);
end
set(fig.main,'Color',bkcolor);
delete(linepoi);


function pushbutton14_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.edit10,'String','');



function edit30_Callback(hObject, eventdata, handles)
% hObject    handle to edit30 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit30 as text
%        str2double(get(hObject,'String')) returns contents of edit30 as a double


% --- Executes during object creation, after setting all properties.
function edit30_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit30 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit29_Callback(hObject, eventdata, handles)
% hObject    handle to edit29 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit29 as text
%        str2double(get(hObject,'String')) returns contents of edit29 as a double


% --- Executes during object creation, after setting all properties.
function edit29_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit29 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit31_Callback(hObject, eventdata, handles)
% hObject    handle to edit31 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit31 as text
%        str2double(get(hObject,'String')) returns contents of edit31 as a double


% --- Executes during object creation, after setting all properties.
function edit31_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit31 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
