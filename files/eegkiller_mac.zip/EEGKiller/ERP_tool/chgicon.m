function chgicon(h,filename)
%CHGICON changes the figure icon.
%CHGICON(H,FILENAME) changes the icon of a figure to an image specified by
%the string FILENAME, where H is a handle to the figure. If the file is not
%in the current directory or in a directory in the MATLAB path,specify the
%full pathname of the location on your system. If FILENAME is not a valid 
%image file name, the function just removes the previous icon of the figure.
%
%Example:
%h = figure;
%chgicon(h,'newIcon.png'); % replace 'newIcon.png' with your image
% IMPORTANT NOTES:
%REPLACING THE MATLAB GUI ICON VIOLATES THE LICENSE AGREEMENT
% OF MATLAB. DO NOT USE THIS FUNCTION COMMERCIALLY.
%%Han Qun, Sept. 2005
%Copyright 2005-2006 Han Qun
%College of Precision Instrument and Opto-Electronics Engineering,
%Tianjin University, 300072, P.R.China.
%Email: junziyang@126.com
%$Revision: 1.0 $
%Date: 2005/12/2
if nargin<2
error('MATLAB:chgicon','%s','Too few input arguments!');
end
if nargin>2
error('MATLAB:chgicon','%s','Too many input arguments!');
end
newIcon = javax.swing.ImageIcon(filename);
javaFrame = get(h,'JavaFrame');
javaFrame.setFigureIcon(newIcon);
