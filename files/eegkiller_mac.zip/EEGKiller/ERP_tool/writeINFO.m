function writeINFO(handles,s)
INFO = get(handles,'String');
INFO{length(INFO)+1} = s;
set(handles,'String',INFO);
drawnow