function B=num2strcell(A)
for i=1:length(A)
    B{i}=num2str(A(i));
end