function wave = totalsreads(people,type,data,chanlocsname,INFOhandle,s)
if ~checks(s)
    writeINFO(INFOhandle,'���ݱ�ʶ��ʽ����');
else
    cells = duans(s);
    totaldata = cell2data(people,type,data,chanlocsname,cells);
    leftk = regexp(s,'{');
    rightk = regexp(s,'}');
    str = ['''',s(1:(leftk(1)-1)),''','];
    for i = 1:(length(leftk)/3)
        if i ==(length(leftk)/3)
            str = [str,'''totaldata(:,',num2str(i),')''',',''',s((rightk(i*3)+1):end),''''];
        else
            str = [str,'''totaldata(:,',num2str(i),')''',',''',s((rightk(i*3)+1):(leftk(i*3+1)-1)),''','];
        end
    end
    str = ['[',str,']'];
    wave = eval(eval(str));
end









function test = checks(s)
leftk = regexp(s,'{');
rightk = regexp(s,'}');
if length(leftk)==length(rightk)&mod(length(leftk),3)==0
    test = 1;
else
    test = 0;
end


function cells = duans(s)
leftk = regexp(s,'{');
rightk = regexp(s,'}');
for i = 1 : (length(leftk)/3)
    cells{i} = s(leftk((i-1)*3+1):rightk(i*3));
end

function line = str2data(people,type,data,chanlocsname,s)
leftk = regexp(s,'{');
rightk = regexp(s,'}');
fenge = regexp(s,'{|}|\|');
peopleduan = fenge(find(fenge>=leftk(1)&fenge<=rightk(1)));
typeduan   = fenge(find(fenge>=leftk(2)&fenge<=rightk(2)));
chanlocsduan = fenge(find(fenge>=leftk(3)&fenge<=rightk(3)));
line = zeros(length(data{1,1}(:,1)),1);
for i = 1:(length(peopleduan)-1)
    for j = 1:(length(typeduan)-1)
        for k = 1:(length(chanlocsduan)-1)
          line = line + data{strmatch(s((peopleduan(i)+1):(peopleduan(i+1)-1)),people,'exact'),...
              strmatch(s((typeduan(j)+1):(typeduan(j+1)-1)),type,'exact')}(:,...
              strmatch(s((chanlocsduan(k)+1):(chanlocsduan(k+1)-1)),chanlocsname,'exact'));
        end
    end
end
line = line/((length(peopleduan)-1)*(length(typeduan)-1)*(length(chanlocsduan)-1));


function totaldata = cell2data(people,type,data,chanlocsname,cells)
for i = 1:length(cells)
    totaldata(:,i) = str2data(people,type,data,chanlocsname,cells{i});
end
