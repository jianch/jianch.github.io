function varargout = Topo_Tool(varargin)
% TOPO_TOOL M-file for Topo_Tool.fig
%      TOPO_TOOL, by itself, creates a new TOPO_TOOL or raises the existing
%      singleton*.
%
%      H = TOPO_TOOL returns the handle to a new TOPO_TOOL or the handle to
%      the existing singleton*.
%
%      TOPO_TOOL('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in TOPO_TOOL.M with the given input arguments.
%
%      TOPO_TOOL('Property','Value',...) creates a new TOPO_TOOL or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Topo_Tool_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Topo_Tool_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Topo_Tool

% Last Modified by GUIDE v2.5 11-Mar-2013 19:38:10

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Topo_Tool_OpeningFcn, ...
                   'gui_OutputFcn',  @Topo_Tool_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Topo_Tool is made visible.
function Topo_Tool_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Topo_Tool (see VARARGIN)

% Choose default command line output for Topo_Tool
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Topo_Tool wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Topo_Tool_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function path_Callback(hObject, eventdata, handles)
% hObject    handle to path (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of path as text
%        str2double(get(hObject,'String')) returns contents of path as a double


% --- Executes during object creation, after setting all properties.
function path_CreateFcn(hObject, eventdata, handles)
% hObject    handle to path (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
set(hObject,'String','D:\CNT\testCNT\people\people-type.avg');
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function people_name_Callback(hObject, eventdata, handles)
% hObject    handle to people_name (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of people_name as text
%        str2double(get(hObject,'String')) returns contents of people_name as a double


% --- Executes during object creation, after setting all properties.
function people_name_CreateFcn(hObject, eventdata, handles)
% hObject    handle to people_name (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function type_Callback(hObject, eventdata, handles)
% hObject    handle to type (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of type as text
%        str2double(get(hObject,'String')) returns contents of type as a double


% --- Executes during object creation, after setting all properties.
function type_CreateFcn(hObject, eventdata, handles)
% hObject    handle to type (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function ele_path_edit_Callback(hObject, eventdata, handles)
% hObject    handle to ele_path_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ele_path_edit as text
%        str2double(get(hObject,'String')) returns contents of ele_path_edit as a double


% --- Executes during object creation, after setting all properties.
function ele_path_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ele_path_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in type_popu.
function type_popu_Callback(hObject, eventdata, handles)
% hObject    handle to type_popu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: contents = get(hObject,'String') returns type_popu contents as cell array
%        contents{get(hObject,'Value')} returns selected item from type_popu


% --- Executes during object creation, after setting all properties.
function type_popu_CreateFcn(hObject, eventdata, handles)
% hObject    handle to type_popu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function timeser_edit_Callback(hObject, eventdata, handles)
% hObject    handle to timeser_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of timeser_edit as text
%        str2double(get(hObject,'String')) returns contents of timeser_edit as a double


% --- Executes during object creation, after setting all properties.
function timeser_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to timeser_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit9_Callback(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit9 as text
%        str2double(get(hObject,'String')) returns contents of edit9 as a double


% --- Executes during object creation, after setting all properties.
function edit9_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit11_Callback(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit11 as text
%        str2double(get(hObject,'String')) returns contents of edit11 as a double


% --- Executes during object creation, after setting all properties.
function edit11_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit8_Callback(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit8 as text
%        str2double(get(hObject,'String')) returns contents of edit8 as a double


% --- Executes during object creation, after setting all properties.
function edit8_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit10_Callback(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit10 as text
%        str2double(get(hObject,'String')) returns contents of edit10 as a double


% --- Executes during object creation, after setting all properties.
function edit10_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in plot.
function plot_Callback(hObject, eventdata, handles)
% hObject    handle to plot (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
try
    load(get(handles.ele_path_edit,'String'));
catch
   set(handles.text55,'String','ERROR:  Can''t find the electrode file');
end
pop_topo_com(handles);
set(handles.text55,'String','HELP:  You can find the figure on the other window');


% --- Executes on button press in OK.
function OK_Callback(hObject, eventdata, handles)
% hObject    handle to OK (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% path = get(handles.path,'String');
try
    AVG = load_avg(handles);
    set(handles.text55,'String','HELP:  Then you can select the Function menu "Topoplot comparer", "Peak detector" or "Arean Means detector"');
catch
    set(handles.text55,'String','ERROR:  Something is wrong with the path of the AVG files');
end 
set(handles.uipanel2,'UserData',AVG);
str_people = get(handles.people_name,'String');
str_people{length(str_people)+1}='Average';
set(handles.type_popu,'String',str_people);
set(handles.type_popu,'Value',1);
if get(handles.checkbox1,'Value')
    set(handles.edit28,'String',get(handles.type,'String'));
end
global data
data = pop_startdata(handles);
set(handles.OK,'UserData',data);
set(handles.pushbutton21,'UserData',data);
set(handles.channel_sel_list,'String',data.channel.name);   %set peak detector channel name
set(handles.channel_list,'String',data.channel.name);   %set area mean channel name
set(handles.uitable1,'ColumnName',get(handles.edit28,'String'));
ROW = get(handles.people_name,'String');
for i=1:length(ROW)
    rowname{i}=[ROW{i},'      '];
end
set(handles.uitable1,'RowName',rowname);
set(handles.uitable1,'ColumnWidth',num2cell(60*ones(1,length(get(handles.edit28,'String')))));
set(handles.text53,'String',...
    [sprintf('%s\n','INFO'),...
    sprintf('people nums      : %-10d\n',length(data.people)),...
    sprintf('type nums           : %-10d\n',length(data.type)),...
    sprintf('channel nums    : %-10d\n',data.channel.num),...
    sprintf('rate                        : %-10d\n',data.rate),...
    sprintf('time min               : %-10d(ms)\n',round(data.time.min*1000)),...
    sprintf('time max              : %-10d(ms)\n',round(data.time.max*1000))]);
    


% --- Executes on button press in topoplot_radiobutton.
function topoplot_radiobutton_Callback(hObject, eventdata, handles)
% hObject    handle to topoplot_radiobutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if get(hObject,'Value')
    set(handles.text55,'String','HELP:  Type the INFO on the top of the "Topoplot compare",then press the button "PLOT"');
    set(handles.uipanel2,'Visible','on');
    set(handles.peak_panel,'Visible','off');
    set(handles.area,'Visible','off');
end
% Hint: get(hObject,'Value') returns toggle state of topoplot_radiobutton


% --- Executes on button press in peak_detect_radiobutton.
function peak_detect_radiobutton_Callback(hObject, eventdata, handles)
% hObject    handle to peak_detect_radiobutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if get(hObject,'Value')
    set(handles.peak_panel,'Position',get(handles.uipanel2,'Position'));
    set(handles.uipanel2,'Visible','off');
    set(handles.area,'Visible','off');
    set(handles.peak_panel,'Visible','on');
    set(handles.text55,'String','HELP:  Select the channel on the left of the "PEAK DETECT"(Hint:press the Ctrl you can select more than 2 channels),When finished all of the INFO on the left,you can push the button "Search Button"');
end
% Hint: get(hObject,'Value') returns toggle state of
% peak_detect_radiobutton


% --- Executes on selection change in channel_sel_list.
function channel_sel_list_Callback(hObject, eventdata, handles)
% hObject    handle to channel_sel_list (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: contents = get(hObject,'String') returns channel_sel_list contents as cell array
%        contents{get(hObject,'Value')} returns selected item from channel_sel_list


% --- Executes on button press in maxmin_togglebutton.
function maxmin_togglebutton_Callback(hObject, eventdata, handles)
% hObject    handle to maxmin_togglebutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if get(hObject,'Value')
    set(hObject,'String','Max');
else
    set(hObject,'String','Min');
end
% Hint: get(hObject,'Value') returns toggle state of maxmin_togglebutton


% --- Executes on button press in togglebutton2.
function togglebutton2_Callback(hObject, eventdata, handles)
% hObject    handle to togglebutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if get(hObject,'Value')
    set(handles.detail_uipanel,'Visible','on');
    set(handles.text36,'Visible','off');
    set(handles.edit27,'Visible','off');
    set(handles.text52,'Visible','off');
    set(handles.edit31,'Visible','off');
else
    set(handles.detail_uipanel,'Visible','off');
    set(handles.text36,'Visible','on');
    set(handles.edit27,'Visible','on');
    set(handles.text52,'Visible','on');
    set(handles.edit31,'Visible','on');
end
% Hint: get(hObject,'Value') returns toggle state of togglebutton2



function edit18_Callback(hObject, eventdata, handles)
% hObject    handle to edit18 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit18 as text
%        str2double(get(hObject,'String')) returns contents of edit18 as a double


% --- Executes during object creation, after setting all properties.
function edit18_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit18 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit19_Callback(hObject, eventdata, handles)
% hObject    handle to edit19 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit19 as text
%        str2double(get(hObject,'String')) returns contents of edit19 as a double


% --- Executes during object creation, after setting all properties.
function edit19_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit19 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit20_Callback(hObject, eventdata, handles)
% hObject    handle to edit20 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit20 as text
%        str2double(get(hObject,'String')) returns contents of edit20 as a double


% --- Executes during object creation, after setting all properties.
function edit20_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit20 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit24_Callback(hObject, eventdata, handles)
% hObject    handle to edit24 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit24 as text
%        str2double(get(hObject,'String')) returns contents of edit24 as a double


% --- Executes during object creation, after setting all properties.
function edit24_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit24 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit25_Callback(hObject, eventdata, handles)
% hObject    handle to edit25 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit25 as text
%        str2double(get(hObject,'String')) returns contents of edit25 as a double


% --- Executes during object creation, after setting all properties.
function edit25_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit25 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit26_Callback(hObject, eventdata, handles)
% hObject    handle to edit26 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit26 as text
%        str2double(get(hObject,'String')) returns contents of edit26 as a double


% --- Executes during object creation, after setting all properties.
function edit26_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit26 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit27_Callback(hObject, eventdata, handles)
% hObject    handle to edit27 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit27 as text
%        str2double(get(hObject,'String')) returns contents of edit27 as a double


% --- Executes during object creation, after setting all properties.
function edit27_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit27 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit28_Callback(hObject, eventdata, handles)
% hObject    handle to edit28 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit28 as text
%        str2double(get(hObject,'String')) returns contents of edit28 as a double


% --- Executes during object creation, after setting all properties.
function edit28_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit28 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in checkbox1.
function checkbox1_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if get(hObject,'Value')
    set(handles.edit28,'Enable','off');
else
    set(handles.edit28,'Enable','on');
end
% Hint: get(hObject,'Value') returns toggle state of checkbox1


% --- Executes on button press in togglebutton3.
function togglebutton3_Callback(hObject, eventdata, handles)
% hObject    handle to togglebutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
SHUJU=get(handles.pushbutton9,'UserData');
if get(hObject,'Value')
    set(hObject,'String','Peak');
    set(handles.uitable1,'Data',reshapedata(SHUJU{1},get(handles.popupmenu3,'Value')));
else
    set(hObject,'String','Latency');
    set(handles.uitable1,'Data',reshapedata(SHUJU{2},get(handles.popupmenu3,'Value')));
end
% Hint: get(hObject,'Value') returns toggle state of togglebutton3


% --- Executes on selection change in popupmenu3.
function popupmenu3_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
SHUJU=get(handles.pushbutton9,'UserData');
if get(handles.togglebutton3,'Value')
    set(handles.uitable1,'Data',reshapedata(SHUJU{1},get(hObject,'Value')));
else
    set(handles.uitable1,'Data',reshapedata(SHUJU{2},get(hObject,'Value')));
end

% Hints: contents = get(hObject,'String') returns popupmenu3 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu3


% --- Executes during object creation, after setting all properties.
function popupmenu3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton8.
function pushbutton8_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if get(hObject,'Value');
data = get(handles.OK,'UserData');
AVG  = get(handles.uipanel2,'UserData');
sel  = get(handles.text45,'UserData');
SHUJU= get(handles.pushbutton9,'UserData');
LAT  = reshapedata(SHUJU{2},get(handles.popupmenu3,'Value'));
AMP  = reshapedata(SHUJU{1},get(handles.popupmenu3,'Value'));
LAT_sgl = LAT(sel(1),sel(2));
AMP_sgl = AMP(sel(1),sel(2));
CHAN_TOL = get(handles.popupmenu3,'String');
CHAN = CHAN_TOL{get(handles.popupmenu3,'Value')};
CHAN_NUM = strmatch(CHAN,data.channel.name,'exact');
plotdata = AVG(sel(1),sel(2)).channel(1,CHAN_NUM).data;
lim = ceil(max(abs(plotdata)))+1;


disp.size=[data.time.min*1000,data.time.max*1000,-lim,lim];
disp.t=((data.time.min*1000):(1000/data.rate):(data.time.max*1000))';
disp.xinterval = 100;
disp.yinterval = 2;
disp.lengthwidth = 1;
disp.x.tick=(round(disp.size(1):disp.xinterval:disp.size(2)));
disp.x.ticklabel=(cellstr(num2str(disp.x.tick')))';
disp.y.tick=round(disp.size(3):disp.yinterval:disp.size(4));
disp.y.ticklabel=(cellstr(num2str(disp.y.tick')))';
axes(handles.axes2);
plot(disp.t,AVG(sel(1),sel(2)).channel(1,CHAN_NUM).data,'LineWidth',disp.lengthwidth);
hold on;
axis(disp.size);
plot(disp.x.tick,zeros(size(disp.x.tick)),'k+-');
plot(zeros(size(disp.y.tick)),disp.y.tick,'k+-');
set(gca,'xtick',disp.x.tick);
set(gca,'XTickLabel',disp.x.ticklabel);
set(gca,'ytick',disp.y.tick);
set(gca,'YTickLabel',disp.y.ticklabel);
set(gca,'Ydir','reverse');
DIS.x =  round(disp.t);
DIS.y =  plotdata;
DIS.dif = 1000/data.rate;
set(hObject,'UserData',DIS);

H.xlimi=[data.time.max*1000-data.time.min*1000]*0.025; 
H.ylimi=2*lim*0.05;
H.Cline=line([LAT_sgl,LAT_sgl],[AMP_sgl-H.ylimi,AMP_sgl+H.ylimi],'Color',[1,0,0]); 
H.xline=line([LAT_sgl-H.xlimi,LAT_sgl+H.xlimi],[AMP_sgl,AMP_sgl],'Color',[1,0,0]); 
H.yline=line([LAT_sgl,LAT_sgl],[AMP_sgl-H.ylimi,AMP_sgl+H.ylimi],'Color',[1,0,0]); 
H.cross=[LAT_sgl,AMP_sgl];
H.dispsize=disp.size;
set(handles.text44,'String',num2str(H.cross(1)));
set(handles.text47,'String',num2str(H.cross(2)));
set(handles.uipanel14,'UserData',H);
hold off
set(hObject,'Enable','off');
set(handles.uitable1,'Enable','off');
set(handles.popupmenu3,'Enable','off');
set(handles.pushbutton10,'Enable','on');
set(handles.pushbutton11,'Enable','on');
set(handles.pushbutton13,'Enable','on');
end

% --- Executes on button press in pushbutton9.
function pushbutton9_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
AVG        = get(handles.uipanel2,'UserData');
time_range = str2num(get(handles.edit27,'String'));
max_or_min = get(handles.maxmin_togglebutton,'Value');
channel_tot= get(handles.channel_sel_list,'String');
channel = channel_tot(get(handles.channel_sel_list,'Value'));
[crest_new,latent_new]=pop_peak_det(AVG,time_range,channel,max_or_min,handles);
latent_new = round(latent_new*1000);
set(hObject,'UserData',{crest_new,latent_new});
set(handles.popupmenu3,'Value',1);
if get(handles.togglebutton3,'Value')
    set(handles.uitable1,'Data',reshapedata(crest_new,get(handles.popupmenu3,'Value')));
else
    set(handles.uitable1,'Data',reshapedata(latent_new,get(handles.popupmenu3,'Value')));
end
set(handles.popupmenu3,'String',channel);
set(handles.pushbutton15,'Enable','on');
set(handles.text55,'String','HELP:  Select the number in the table,then the "edit position" can be pressed,if you press the "edit position",you can change the number by button "��","��" or left click on the figure,after change the number,press the button "OK" on the right.After change the whole numbers,press the button "SAVE",you can find the dat files in the AVG files'' folder.');


% --- Executes on button press in pushbutton13.
function pushbutton13_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.pushbutton8,'Value',0);
set(handles.uitable1,'Enable','on');
sel  = get(handles.text45,'UserData');
H    = get(handles.uipanel14,'UserData');
lat  = get(H.yline,'xdata');
pea  = get(H.xline,'ydata');
SHUJU= get(handles.pushbutton9,'Userdata');
SHUJU{1}(get(handles.popupmenu3,'Value'),sel(1),sel(2))=pea(1);
SHUJU{2}(get(handles.popupmenu3,'Value'),sel(1),sel(2))=lat(1);
set(handles.pushbutton9,'UserData',SHUJU);
if get(handles.togglebutton3,'Value')
    set(handles.uitable1,'Data',reshapedata(SHUJU{1},get(handles.popupmenu3,'Value')));
else
    set(handles.uitable1,'Data',reshapedata(SHUJU{2},get(handles.popupmenu3,'Value')));
end
set(handles.popupmenu3,'Enable','on');
set(hObject,'Enable','off');
set(handles.pushbutton10,'Enable','off');
set(handles.pushbutton11,'Enable','off');


% --- Executes on button press in pushbutton10.
function pushbutton10_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
DIS = get(handles.pushbutton8,'UserData');
H   = get(handles.uipanel14,'UserData');
x   = get(H.yline,'xdata');
pos_axes_dip(1) = round(x(1)-DIS.dif);
pos_axes_dip(2) = DIS.y(find(DIS.x==pos_axes_dip(1)));
set(H.xline,'xdata',[pos_axes_dip(1)-H.xlimi,pos_axes_dip(1)+H.xlimi]); 
set(H.xline,'ydata',[pos_axes_dip(2),pos_axes_dip(2)]); 
set(H.yline,'xdata',[pos_axes_dip(1),pos_axes_dip(1)]); 
set(H.yline,'ydata',[pos_axes_dip(2)-H.ylimi,pos_axes_dip(2)+H.ylimi]); 
set(handles.text44,'String',num2str(pos_axes_dip(1)));
set(handles.text47,'String',num2str(pos_axes_dip(2)));




% --- Executes on button press in pushbutton11.
function pushbutton11_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
DIS = get(handles.pushbutton8,'UserData');
H   = get(handles.uipanel14,'UserData');
x   = get(H.yline,'xdata');
pos_axes_dip(1) = round(x(1)+DIS.dif);
pos_axes_dip(2) = DIS.y(find(DIS.x==pos_axes_dip(1)));
set(H.xline,'xdata',[pos_axes_dip(1)-H.xlimi,pos_axes_dip(1)+H.xlimi]); 
set(H.xline,'ydata',[pos_axes_dip(2),pos_axes_dip(2)]); 
set(H.yline,'xdata',[pos_axes_dip(1),pos_axes_dip(1)]); 
set(H.yline,'ydata',[pos_axes_dip(2)-H.ylimi,pos_axes_dip(2)+H.ylimi]); 
set(handles.text44,'String',num2str(pos_axes_dip(1)));
set(handles.text47,'String',num2str(pos_axes_dip(2)));

% --- Executes when selected cell(s) is changed in uitable1.

function uitable1_CellSelectionCallback(hObject, eventdata, handles)
% hObject    handle to uitable1 (see GCBO)
% eventdata  structure with the following fields (see UITABLE)
%	Indices: row and column indices of the cell(s) currently selecteds
% handles    structure with handles and user data (see GUIDATA)
if ~isempty(eventdata.Indices)

sel = eventdata.Indices(end,:);
set(handles.text45,'UserData',sel);
data = get(handles.OK,'UserData');
AVG  = get(handles.uipanel2,'UserData');
sel  = get(handles.text45,'UserData');
SHUJU= get(handles.pushbutton9,'UserData');
LAT  = reshapedata(SHUJU{2},get(handles.popupmenu3,'Value'));
AMP  = reshapedata(SHUJU{1},get(handles.popupmenu3,'Value'));
LAT_sgl = LAT(sel(1),sel(2));
AMP_sgl = AMP(sel(1),sel(2));
CHAN_TOL = get(handles.popupmenu3,'String');
CHAN = CHAN_TOL{get(handles.popupmenu3,'Value')};
CHAN_NUM = strmatch(CHAN,data.channel.name,'exact');
plotdata = AVG(sel(1),sel(2)).channel(1,CHAN_NUM).data;
lim = ceil(max(abs(plotdata)))+1;


disp.size=[data.time.min*1000,data.time.max*1000,-lim,lim];
disp.t=((data.time.min*1000):(1000/data.rate):(data.time.max*1000))';
disp.xinterval = 100;
disp.yinterval = 2;
disp.lengthwidth = 1;
disp.x.tick=(round(disp.size(1):disp.xinterval:disp.size(2)));
disp.x.ticklabel=(cellstr(num2str(disp.x.tick')))';
disp.y.tick=round(disp.size(3):disp.yinterval:disp.size(4));
disp.y.ticklabel=(cellstr(num2str(disp.y.tick')))';
axes(handles.axes2);
plot(disp.t,AVG(sel(1),sel(2)).channel(1,CHAN_NUM).data,'LineWidth',disp.lengthwidth);
hold on;
axis(disp.size);
plot(disp.x.tick,zeros(size(disp.x.tick)),'k+-');
plot(zeros(size(disp.y.tick)),disp.y.tick,'k+-');
set(gca,'xtick',disp.x.tick);
set(gca,'XTickLabel',disp.x.ticklabel);
set(gca,'ytick',disp.y.tick);
set(gca,'YTickLabel',disp.y.ticklabel);
set(gca,'Ydir','reverse');
DIS.x =  round(disp.t);
DIS.y =  plotdata;
DIS.dif = 1000/data.rate;
set(hObject,'UserData',DIS);

H.xlimi=[data.time.max*1000-data.time.min*1000]*0.025; 
H.ylimi=2*lim*0.05;
H.Cline=line([LAT_sgl,LAT_sgl],[AMP_sgl-H.ylimi,AMP_sgl+H.ylimi],'Color',[1,0,0]); 
H.xline=line([LAT_sgl-H.xlimi,LAT_sgl+H.xlimi],[AMP_sgl,AMP_sgl],'Color',[1,0,0]); 
H.yline=line([LAT_sgl,LAT_sgl],[AMP_sgl-H.ylimi,AMP_sgl+H.ylimi],'Color',[1,0,0]); 
H.cross=[LAT_sgl,AMP_sgl];
H.dispsize=disp.size;
set(handles.text44,'String',num2str(H.cross(1)));
set(handles.text47,'String',num2str(H.cross(2)));
set(handles.uipanel14,'UserData',H);
hold off

PEO = get(handles.people_name,'String');
TYPE= get(handles.edit28,'String');
if ~iscell(TYPE)
    TYPE = cellstr(TYPE);
end
set(handles.text45,'String',PEO{sel(1)});
set(handles.text46,'String',TYPE{sel(2)});
set(handles.pushbutton8,'Enable','on');
end


% --- Executes on mouse motion over figure - except title and menu.
function figure1_WindowButtonMotionFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if get(handles.pushbutton8,'Value')
pos_axes_real = get(handles.axes2,'CurrentPoint');
H  = get(handles.uipanel14,'UserData');
set(hObject,'Pointer','arrow');
DIS = get(handles.pushbutton8,'UserData');
if (~isempty(H))&(pos_axes_real(1,1)<=H.dispsize(2))&(pos_axes_real(1,1)>=H.dispsize(1))&(pos_axes_real(1,2)<=H.dispsize(4))&(pos_axes_real(1,2)>=H.dispsize(3))
    set(hObject,'Pointer','crosshair');
    pos_axes_dip(1) = DIS.dif*round(pos_axes_real(1,1)/DIS.dif);
    pos_axes_dip(2) = DIS.y(find(DIS.x==pos_axes_dip(1)));
    set(H.Cline,'xdata',[pos_axes_dip(1),pos_axes_dip(1)]); 
    set(H.Cline,'ydata',[pos_axes_dip(2)-H.ylimi,pos_axes_dip(2)+H.ylimi]); 
    set(handles.text48,'String',num2str(pos_axes_dip(1)));
    set(handles.text49,'String',num2str(pos_axes_dip(2)));
end
end


% --- Executes on mouse press over figure background, over a disabled or
% --- inactive control, or over an axes background.
function figure1_WindowButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if get(handles.pushbutton8,'Value')
    pos_axes_real = get(handles.axes2,'CurrentPoint');
    H  = get(handles.uipanel14,'UserData');
    if (~isempty(H))&(pos_axes_real(1,1)<=H.dispsize(2))&(pos_axes_real(1,1)>=H.dispsize(1))&(pos_axes_real(1,2)<=H.dispsize(4))&(pos_axes_real(1,2)>=H.dispsize(3))
        DIS = get(handles.pushbutton8,'UserData');
        pos_axes_dip(1) = DIS.dif*round(pos_axes_real(1,1)/DIS.dif);
        pos_axes_dip(2) = DIS.y(find(DIS.x==pos_axes_dip(1)));
        set(H.xline,'xdata',[pos_axes_dip(1)-H.xlimi,pos_axes_dip(1)+H.xlimi]); 
        set(H.xline,'ydata',[pos_axes_dip(2),pos_axes_dip(2)]); 
        set(H.yline,'xdata',[pos_axes_dip(1),pos_axes_dip(1)]); 
        set(H.yline,'ydata',[pos_axes_dip(2)-H.ylimi,pos_axes_dip(2)+H.ylimi]); 
        set(handles.text44,'String',num2str(pos_axes_dip(1)));
        set(handles.text47,'String',num2str(pos_axes_dip(2)));
    end
end

    
    



function edit31_Callback(hObject, eventdata, handles)
% hObject    handle to edit31 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit31 as text
%        str2double(get(hObject,'String')) returns contents of edit31 as a double


% --- Executes during object creation, after setting all properties.
function edit31_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit31 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton15.
function pushbutton15_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
SHUJU=get(handles.pushbutton9,'UserData');
pop_spsdata(SHUJU{1},'Amplitude',handles);
pop_spsdata(SHUJU{2},'Latency',handles);


% --- Executes on button press in pushbutton17.
function pushbutton17_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton17 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton18.
function pushbutton18_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton18 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
path   = get(handles.path,'String');
people = get(handles.people_name,'String');
type   = cellstr(get(handles.type,'String'));

chanlocs = avgchanlocs(path,people,type,handles.text55);

save([pwd,'\Temporal_files\','channellocs'],'chanlocs');

set(handles.ele_path_edit,'String',[pwd,'\Temporal_files\channellocs.mat']);






% --- Executes on button press in pushbutton19.
function pushbutton19_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton19 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
data.path = get(handles.path,'String');
data.people = get(handles.people_name,'String');
data.type = get(handles.type,'String');
data.tag  = get(handles.edit28,'String');
data.samevalue = get(handles.checkbox1,'Value');
save(uiputfile,'data')
% uiputfile('*.mat','����people,type��tag��Ϣ')


% --- Executes on button press in pushbutton20.
function pushbutton20_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton20 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
load(uigetfile('*.mat','�����MAT�ļ�'));
set(handles.path,'String',data.path);
set(handles.people_name,'String',data.people);
set(handles.type,'String',data.type);
set(handles.edit28,'String',data.tag);
set(handles.checkbox1,'Value',data.samevalue);
if data.samevalue
    set(handles.edit28,'Enable','off');
else
    set(handles.edit28,'Enable','on');
end



function edit32_Callback(hObject, eventdata, handles)
% hObject    handle to edit32 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit32 as text
%        str2double(get(hObject,'String')) returns contents of edit32 as a double


% --- Executes during object creation, after setting all properties.
function edit32_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit32 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes when uipanel5 is resized.
function uipanel5_ResizeFcn(hObject, eventdata, handles)
% hObject    handle to uipanel5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in radiobutton8.
function radiobutton8_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if get(hObject,'Value')
    set(handles.area,'Position',get(handles.uipanel2,'Position'));
    set(handles.uipanel2,'Visible','off');
    set(handles.peak_panel,'Visible','off');
    set(handles.area,'Visible','on');
    set(handles.text55,'String','HELP:  You can difine a time range to export the area mean of specific eletrodes');
end

% Hint: get(hObject,'Value') returns toggle state of radiobutton8


% --- Executes on selection change in channel_list.
function channel_list_Callback(hObject, eventdata, handles)
% hObject    handle to channel_list (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns channel_list contents as cell array
%        contents{get(hObject,'Value')} returns selected item from channel_list


% --- Executes during object creation, after setting all properties.
function channel_list_CreateFcn(hObject, eventdata, handles)
% hObject    handle to channel_list (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton21.
function pushbutton21_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton21 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
AVG        = get(handles.uipanel2,'UserData');
timerange = str2num(get(handles.edit32,'String'));
channel_tot= get(handles.channel_list,'String');
channel = channel_tot(get(handles.channel_list,'Value'));
baseline = get(handles.edit33,'String');
rate     = get(handles.edit34,'String');
areameans = meanarea(AVG,timerange,channel,str2num(baseline),str2num(rate),handles.OK,handles.text55);
dlmwrite([get(handles.edit35,'String'),'\',get(handles.edit36,'String')],areameans);


function edit33_Callback(hObject, eventdata, handles)
% hObject    handle to edit33 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit33 as text
%        str2double(get(hObject,'String')) returns contents of edit33 as a double


% --- Executes during object creation, after setting all properties.
function edit33_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit33 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit34_Callback(hObject, eventdata, handles)
% hObject    handle to edit34 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit34 as text
%        str2double(get(hObject,'String')) returns contents of edit34 as a double


% --- Executes during object creation, after setting all properties.
function edit34_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit34 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit35_Callback(hObject, eventdata, handles)
% hObject    handle to edit35 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit35 as text
%        str2double(get(hObject,'String')) returns contents of edit35 as a double


% --- Executes during object creation, after setting all properties.
function edit35_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit35 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton22.
function pushbutton22_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton22 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
path = uigetdir;
set(handles.edit35,'String',path);




function edit36_Callback(hObject, eventdata, handles)
% hObject    handle to edit36 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit36 as text
%        str2double(get(hObject,'String')) returns contents of edit36 as a double


% --- Executes during object creation, after setting all properties.
function edit36_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit36 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
