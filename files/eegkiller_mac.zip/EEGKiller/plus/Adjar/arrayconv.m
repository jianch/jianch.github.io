function newwave=arrayconv(distribute,wave)
for i=1:size(wave,2)
    newwave(:,i)=conv(distribute,wave(:,i));
end
