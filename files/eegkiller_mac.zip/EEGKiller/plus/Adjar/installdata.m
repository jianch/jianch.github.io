function data=installdata()
data.channel=70;
data.samplingrate=500;
data.delay=0.05;
data.range=[-0.3,0.6];
data.cue.name={'11,13','12,14','15,17','16,18'}; %
data.cue.code={[11,13],[12,14],[15,17],[16,18]}; %
data.target.name={'31','32','33','34','35','36','37','38'}; %
data.target.code={[31],[32],[33],[34],[35],[36],[37],[38]}; %
data.relation.randtime.onset=[0.05,0.25]; %
data.relation.aftercue={[1,3],[2,4],[5,7],[6,8]}; %
data.relation.beforetarget={[1],[2],[1],[2],[3],[4],[3],[4]}; %


%data.channel=1;
%data.samplingrate=500;
%data.delay=0;
%data.cue.name={'5'};
%data.cue.code={[5]};
%data.target.name={'6'};
%data.target.code={[6]};
%data.relation.randtime=[0.3,0.5];
%data.relation.aftercue={[1]};
%data.relation.beforetarget={[1]};