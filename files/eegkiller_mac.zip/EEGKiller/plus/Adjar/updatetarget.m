function [target_wave_update,target_wave_updata_base]=updatetarget(cue_wave,target_wave,previous,target_wave_org)
global data
n=-data.range(1)*data.samplingrate;
for i=1:size(previous,1)
    cue_effect=zeros(size(cue_wave,2)+length(previous{1,1})-1,size(cue_wave,3));
    for j=1:size(data.relation.beforetarget{1})
        cue_effect=cue_effect+arrayconv(previous{i,j},reshapedata(cue_wave,data.relation.beforetarget{i}(j)));
    end
    target_wave_nonbase=arraycut(cue_effect,reshapedata(target_wave_org,i),2);
    baseline=mean(target_wave_nonbase(1:n,:),1);
    baseline_block=ones(size(target_wave_nonbase,1),1)*baseline;
    target_wave_base=target_wave_nonbase-baseline_block;
    target_wave_update(i,:,:)=target_wave_nonbase;
    target_wave_updata_base(i,:,:)=target_wave_base;
end