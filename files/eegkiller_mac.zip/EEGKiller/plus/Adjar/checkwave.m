function result=checkwave(target_wave,channel)
global data
n=-data.range(1)*data.samplingrate;
for i=1:length(data.target.name)
    wave=reshapedata(target_wave,i);
    V(i)=mean(var(wave(1:n,channel),1));
end
result=mean(V);