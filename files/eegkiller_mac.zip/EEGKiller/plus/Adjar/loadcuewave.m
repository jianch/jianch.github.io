function cue_wave=loadcuewave(filename)
global data;
for i=1:length(data.cue.name)
    filename1=[filename,'-',data.cue.name{i},'.avg'];
    cue_wave(i,:,:)=loadavg(filename1);
end