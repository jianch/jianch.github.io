function wave = readequation(people,type,data,INFOhandle,s)
if ~checks(s)
    writeINFO(INFOhandle,'��ʽ��ʽ����');
else
    cells = duans(s);
    totaldata = cell2data(people,type,data,cells);
    leftk = regexp(s,'{');
    rightk = regexp(s,'}');
    str = ['''',s(1:(leftk(1)-1)),''','];
    for i = 1:(length(leftk)/2)
        if i == (length(leftk)/2)
            str = [str,'''totaldata(:,:,',num2str(i),')''',',''',s((rightk(i*2)+1):end),''''];
        else
            str = [str,'''totaldata(:,:,',num2str(i),')''',',''',s((rightk(i*2)+1):(leftk(i*2+1)-1)),''','];
        end
    end
    str = ['[',str,']'];
    eval(str)
    wave = eval(eval(str))
    size(wave);
end


function test = checks(s)
leftk = regexp(s,'{');
rightk = regexp(s,'}');
if length(leftk)==length(rightk)&mod(length(leftk),2)==0
    test = 1;
else
    test = 0;
end


function cells = duans(s)
leftk = regexp(s,'{');
rightk = regexp(s,'}');
for i = 1 : (length(leftk)/2)
    cells{i} = s(leftk((i-1)*2+1):rightk(i*2));
end

function line = str2data(people,type,data,s)
leftk = regexp(s,'{');
rightk = regexp(s,'}');
fenge = regexp(s,'{|}|\|');
peopleduan = fenge(find(fenge>=leftk(1)&fenge<=rightk(1)));
typeduan   = fenge(find(fenge>=leftk(2)&fenge<=rightk(2)));
line = zeros(size(data{1,1}));
for i = 1:(length(peopleduan)-1)
    for j = 1:(length(typeduan)-1)
        line = line + data{strmatch(s((peopleduan(i)+1):(peopleduan(i+1)-1)),people,'exact'),...
        strmatch(s((typeduan(j)+1):(typeduan(j+1)-1)),type,'exact')};
    end
end
line = line/((length(peopleduan)-1)*(length(typeduan)-1));


function totaldata = cell2data(people,type,data,cells)
for i = 1:length(cells)
    totaldata(:,:,i) = str2data(people,type,data,cells{i});
end