function newavg = mergeavg(filetype1,filetype2,operation,newname)
file1     = eeg_load_scan4_avg(filetype1);
file2     = eeg_load_scan4_avg(filetype2);
opera     = operation; %'-' or '+'
name      = newname;

if ~isempty(file1)&~isempty(file2)&~isempty(opera)&~isempty(name)  
    for i = 1:length(file1.data)
        if strcmp(opera,'-')
            disp([filetype1,'  -  ',filetype2])
            newdata = file1.data(1,i).samples-file2.data(1,i).samples;
            
            
        else
            disp([filetype1,'+',filetype2])
            newdata = file1.data(1,i).samples+file2.data(1,i).samples;
            file1.data(1,i).samples = newdata;
            eeg_write_scan4_avg(file1,name);
        end
    end
end
file1.data = newdata;
eeg_write_scan4_avg(file1,name);
        
        
        
        
