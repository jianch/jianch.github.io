function analysiscnt()
%% ���û�����Ϣ
disp('......set infomation......');
disp('--------------------------------------------------------------------------------');
disp('   ');
% ������Ϣ
ana.path       = 'D:\QYY\';
%ana.filename   = {'visible_01','visible_06','visible_07','visible_08','visible_09','visible_13','visible_15','visible_17','visible_23','visible_24','visible_26','visible_22'};
ana.filename   = {'sub-01','sub-02' };
ana.srate      = 500;
% �ο��缫��Ϣ
ana.ref.chan        = {'A1'}; %'all' %{'M1','M2'}; % {'A1','A2'}
% �˲���Ϣ
ana.filt.low        = 1;
ana.filt.high       = 30;
% epoch��Ϣ
ana.epoch.timerange  = [-200,600];
ana.epoch.timen      = ana.epoch.timerange*ana.srate/1000;
ana.epoch.more       = 150;
ana.epoch.timen_more = ana.epoch.timen + [-ana.epoch.more,ana.epoch.more];
ana.epoch.time       = ana.epoch.timerange(1):(1000/ana.srate):ana.epoch.timerange(2);
ana.epoch.code       = {[31,32],[33,34],[35,36],[37,38]};
ana.epoch.totalcode  = [];
name                 = {'SL','SH','BL','BH'};
rename               = 'new';
ana.epoch.name       = strcat(rename,name);
ana.epoch.wipecode   = [256];
for i = 1:length(ana.epoch.code);  ana.epoch.totalcode = [ana.epoch.totalcode,ana.epoch.code{i}]; end
ana.epoch.totalcode = unique(ana.epoch.totalcode);
% baseline��Ϣ
ana.baseline.timerange   = [-200,0];
% ȥα����Ϣ
ana.adj.lim  =  75;
ana.adj.chan = {'FP1','FP2','HEOG','VEOG'};
%% ���ݴ���
for i = 1:length(ana.filename)
    disp(['......analysis file ',ana.filename{i},'......']);
    disp('   ');
    filename = [ana.path,ana.filename{i},'\',ana.filename{i},'.cnt'];    % �����ļ���
    chan  = load_channel(filename);    % ��ȡ�缫��Ϣ
    event = load_event(filename);    % ��ȡevent��Ϣ
    sel_event_logical = arrayinarray(ana.epoch.totalcode,event(:,1));
    % ѭ��ÿ������
    for code = 1:length(ana.epoch.code)
        disp(['......analysis type ',ana.epoch.name{code},'......']);
        [code_logic,code_order] = arrayinarray(ana.epoch.code{code},event(:,1),'on');
        timerange = {};
        AVGdata   = [];
        count     = 0;
        avg.chan  = chan;
        avg.event = event(code_logic,:);
        avg.xmin  = ana.epoch.timerange(1)/1000;
        avg.xmax  = ana.epoch.timerange(2)/1000 + 1/ana.srate;
        avg.dispxmin = ana.epoch.timerange(1)/1000;
        avg.dispxmax = ana.epoch.timerange(2)/1000;
        avg.adjlim   = ana.adj.lim;
        % ѭ��ѡ��code��event
        dispcount = 0; %��������
        dispnum   = round(length(code_order)/50);
        for index = code_order
            dispcount = dispcount + 1;
            if mod(dispcount,dispnum) == 1
                fprintf('>')
            end
            flag   = 1; %����flag
            flag_adj = 0;
            poi  = 1; %����Ѱ����һ��true��Сָ��
            % �ж����event�Ƿ��������������������flag = 0
            if index ~= length(event(:,1)) %�ж�ָ���Ƿ������һ��
                while ~sel_event_logical(index+poi)
                    if ~isempty(find(ana.epoch.wipecode == event(index+poi,1), 1)) & (index+poi) ~= (length(event(:,1))-1) & (index+poi) ~= (length(event(:,1))) %�����һ��event��wipe��
                        flag = 0;
                        break
                    elseif (index+poi) == length(event(:,1))-1 %���index+poi�ǵ����ڶ���event
                        if ~isempty(find(ana.epoch.wipecode == event(end,1), 1)) % ���һ��event��wipe��
                            flag = 0;
                            break
                        else
                            break
                        end
                    elseif (index+poi) == length(event(:,1)) %���index+poi�ǵ�����һ��
                        break
                    else
                        poi = poi + 1;
                    end
                end
            end
            % ���flag = 1����ʼȡ���ݼ����Ƿ���α��
            if flag
                [mm,adjchan] = arrayinarray(ana.adj.chan,chan);
                adjrange    = ana.epoch.timen_more + event(index,2);
                org_data = load_data(filename,'all',adjrange);                           %ȡԭʼ����
                ref_data = refdata(org_data,ana.ref,chan);                               %�ο�ת��
                smoothdata = eegfiltfft(ref_data',ana.srate,ana.filt.low,ana.filt.high); %�˲�
                %smoothdata = eegfiltfft(smoothdata,ana.srate,19,21,0,[],1); %�˲�
                simdata    = smoothdata(:,(ana.epoch.more+1):(size(smoothdata,2)-ana.epoch.more))'; 
                anadata = baseline(simdata,ana.epoch,ana.baseline);                  %baseline
                if ~detectionadj(anadata,ana,chan)                                       %���α��
                    flag_adj = 1;
                end
            end
            if flag_adj  %event������������adj����
                count   = count + 1;
                AVGdata(:,:,count) = anadata;
            end
        end
        save([filename(1:(end-4)),'-',ana.epoch.name{code},'.mat'],AVGdata);
        avg.acceptcount = count;
        avg.rejcount    = size(avg.event,1)-count;
        fprintf('\n');
        disp('......cnt to avg......');
        f = cnt2avg(filename,AVGdata,avg);                                               %���ֵ
        disp(['......write ',filename(1:(end-4)),'-',ana.epoch.name{code},'......']);
        eeg_write_scan4_avg(f,[filename(1:(end-4)),'-',ana.epoch.name{code},'.avg']);
    end
end
