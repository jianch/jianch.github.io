function [logicalarray,indexarray] = arrayinarray(small,big,sorttype)
if (nargin == 2)
    sorttype = 'off';
end
if size(small,1)>1
    small = small';
end
if size(big,1)>1
    big = big';
end

logicalarray = false(1,length(big));
indexarray   = [];
if ~iscell(small)
    for i = 1:length(small)
        logicsingle  = big==small(i);
        logicalarray = logicalarray | logicsingle;
        indexarray   = [indexarray,find(logicsingle)];
    end
else
    for i = 1:length(small)
        indexsingle  = strmatch(small{i},big,'exact');
        indexarray   = [indexarray,indexsingle];
    end
    logicalarray = index2logic(length(big),indexarray);
end
if strcmp(sorttype,'on')
    indexarray = sort(indexarray);
end

function A = index2logic(arraylength,B)
A = false(1,arraylength);
for i = B
    A(i) = true;
end
A = logical(A);
