// Author: Saturn Jian Chen 
// www.jianchen.info
// School of Psychological Sciences, The University of Melbourne

// Wait for click
chrome.browserAction.onClicked.addListener(function(tab) {
  chrome.tabs.executeScript(null, {
  	"file": "popup.js"
  }, function(){ 
  	"popup.js";
  	console.log("Script Executed ...");
  });
})