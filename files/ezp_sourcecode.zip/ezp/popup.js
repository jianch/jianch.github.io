// Author: Saturn Jian Chen 
// www.jianchen.info
// School of Psychological Sciences, The University of Melbourne

// Change the url to library when on click
var l=location;l.href=l.origin+l.href.replace(l.origin, '.ezp.lib.unimelb.edu.au');

