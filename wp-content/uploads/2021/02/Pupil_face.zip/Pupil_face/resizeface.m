%function resize face and rotate face

%input expected eye distance
%distance_set = input('input the eye distance you want:');
distance_set = 100;

for k = 1:length(face)
    %find the eye position
    eye.L.value(k) = face{1,k}.position.eye_left;
    eye.R.value(k) = face{1,k}.position.eye_right;
    eye.L.position(k) = struct('x', img_width*face{1,k}.position.eye_left.x/100, 'y', img_height*face{1,k}.position.eye_left.y/100);
    eye.R.position(k) = struct('x', img_width*face{1,k}.position.eye_right.x/100, 'y', img_height*face{1,k}.position.eye_right.y/100);
    if eye.R.position(k).y - eye.L.position(k).y >= 0
        %resize face
        eye.distance(k) = sqrt((eye.R.position(k).x - eye.L.position(k).x).^2 + (eye.R.position(k).y - eye.L.position(k).y).^2);
        face_im_resize{k} = imresize(face_im,distance_set/eye.distance(k));
        %figure; imshow(face_im_resize{k});
        %rotate face
        eye.angle(k) = asind((eye.R.position(k).y - eye.L.position(k).y)/eye.distance(k));
        face_im_rotate{k} = imrotate(face_im_resize{k},eye.angle(k));
        %figure; imshow(face_im_rotate{k});
    else
        %resize face
        eye.distance(k) = sqrt((eye.R.position(k).x - eye.L.position(k).x).^2 + (eye.L.position(k).y - eye.R.position(k).y).^2);
        face_im_resize{k} = imresize(face_im,distance_set/eye.distance(k));
        %figure; imshow(face_im_resize{k});
        %rotate face
        eye.angle(k) = asind((eye.R.position(k).y - eye.L.position(k).y)/eye.distance(k));
        face_im_rotate{k} = imrotate(face_im_resize{k},eye.angle(k));
        %figure; imshow(face_im_rotate{k});
    end
    
    newface{k} = rgb2gray(face_im_rotate{k});
    imwrite(newface{k},[pwd,'/output_face/',filename{n}(1:end-4),'-resize_rotate',num2str(k),'.jpg']);
    disp([filename{n},'  saved']);
    %figure; imshow(newface{k});
    
end




