function addpaths()

disp('   ');
disp('   ');
disp('   ');
disp('   ');
% disp('-------------------------------------------------------------------
% ----------');
disp('-----------------------------------------------------------------------------');
disp('EEGKILLER       Version 1.0       EEGKILLER       Version 1.0       EEGKILLER')
disp('-----------------------------------------------------------------------------');
disp('-----------------------------------------------------------------------------');
disp('Add sepecified directory to the current Matlab path'); 
disp([pwd])
addpath([pwd])

disp([pwd,'/cdata'])
addpath([pwd,'/cdata'])
addpath([pwd,'/cdata/temp'])
addpath([pwd,'/cdata/ParameterTemp'])

disp([pwd,'/ERP_tool'])
addpath([pwd,'/ERP_tool'])
addpath([pwd,'/ERP_tool/chanlocs'])
addpath([pwd,'/ERP_tool/teminfo'])

disp([pwd,'/Topographic'])
addpath([pwd,'/Topographic'])
addpath([pwd,'/Topographic/avgchannels'])
addpath([pwd,'/Topographic/temporal_file'])

disp([pwd,'/plus'])
addpath([pwd,'/plus'])
disp([pwd,'/plus/adjar'])
addpath([pwd,'/plus/adjar'])
% disp([pwd,'/plus/Figure_tool'])
% addpath([pwd,'/plus/Figure_tool'])
disp([pwd,'/plus/Rename_tool'])
addpath([pwd,'/plus/Rename_tool'])

disp([pwd,'/save_load_files'])
addpath([pwd,'/save_load_files'])
disp([pwd,'/Temporal_files'])
addpath([pwd,'/Temporal_files'])


disp([pwd,'/doucuments'])
addpath([pwd,'/documents'])
% disp('-------------------------------------------------------------------
% ----------');
disp('-----------------------------------------------------------------------------');

disp('Ready!');
disp('   ');
disp('   ');