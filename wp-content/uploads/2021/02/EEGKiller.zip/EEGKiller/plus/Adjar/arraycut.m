function newdata=arraycut(data1,data2,type)
global data
if type==1
    n=round((data.relation.randtime.onset(1)+data.delay)/(1/data.samplingrate));
    result_effect=data1(n+1:end,:)-data2(1:(size(data1,1)-n),:);
    newdata=[data1(1:n,:);result_effect];
elseif type==2
    n=round((data.relation.randtime.onset(2)+data.delay)/(1/data.samplingrate));
    result_effect=data2(1:(size(data1,1)-n),:)-data1(n+1:end,:);
    newdata=[result_effect;data2((size(result_effect,1)+1):end,:)];
else
end