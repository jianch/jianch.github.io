function [subsequent,previous]=distribution(code,RT)
global data;
cue_num=length(data.cue.name);
target_num=length(data.target.name);
aftercue_each_num=length(data.relation.aftercue{1});
beforetarget_each_num=length(data.relation.beforetarget{1});
subsequent={};
previous={};
%%%%%%%%%%%subsequent
for i=1:cue_num
    N=[];
    M=0;
    for j=1:aftercue_each_num
        subsequent{i,j}=findcode(code,RT,data.cue.code{i},data.target.code{data.relation.aftercue{i}(j)});
        N(j)=sum(subsequent{i,j});
    end
    M=sum(N);
    for j=1:aftercue_each_num
        subsequent{i,j}=subsequent{i,j}/M;
    end
end
%%%%%%%%%%%previous
for i=1:target_num
    N=[];
    M=0;
    for j=1:beforetarget_each_num
        previous{i,j}=fliplr(findcode(code,RT,data.cue.code{data.relation.beforetarget{i}(j)},data.target.code{i}));
        N(j)=sum(previous{i,j});
    end
    M=sum(N);
    for t=1:beforetarget_each_num
        previous{i,j}=previous{i,j}/M;
    end
end
