function target_wave=loadtargetwave(filename)
global data;
for i=1:length(data.target.name)
    filename1=[filename,'-',data.target.name{i},'.avg'];
    target_wave(i,:,:)=loadavg(filename1);
end