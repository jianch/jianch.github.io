function cue_wave_update=updatecue(cue_wave,target_wave,subsequent,cue_wave_org)
global data
for i=1:size(subsequent,1)
    target_effect=zeros(size(target_wave,2)+length(subsequent{1,1})-1,size(target_wave,3));
    for j=1:size(data.relation.aftercue{1})
        target_effect=target_effect+arrayconv(subsequent{i,j},reshapedata(target_wave,data.relation.aftercue{i}(j)));
    end
    cue_wave_update(i,:,:)=arraycut(reshapedata(cue_wave_org,i),target_effect,1);
end