function equation = writeequation(handle1,handle2)

array1  = get(handle1,'Value');
cells1  = get(handle1,'String');
s1      = swrites(array1,cells1);

array2  = get(handle2,'Value');
cells2  = get(handle2,'String');
s2      = swrites(array2,cells2);

equation = [s1,'_',s2];


function  equation = swrites(array,cells)

num         = length(array);
equation    = [];

for i = 1:num
    if i == 1   %���ֻ��ѡ����һ��
        equation = [equation,cells{array(i)}];
    else   %ѡ�ж��
        equation = [equation,'|',cells{array(i)}];
    end
end

equation = ['{',equation,'}'];