function [doyouexist] = checkfile(path,people,type,handles)

for  i = 1:length(people)
for  j = 1:length(type)
    
    filename = eval(changepath(path));
    
    if exist(filename) == 2
        doyouexist(i,j) = 1;
        INFO = get(handles,'String');
        INFO{length(INFO)+1} = [filename,'�ļ�����'];
        set(handles,'String',INFO);
        drawnow
    else
        doyouexist(i,j) = 2;
        INFO = get(handles,'String');
        INFO{length(INFO)+1} = [filename,'�ļ�������'];
        set(handles,'String',INFO);
        drawnow
    end
end
end

