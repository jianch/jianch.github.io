function varargout = pop_saveinfo(varargin)
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @pop_saveinfo_OpeningFcn, ...
                   'gui_OutputFcn',  @pop_saveinfo_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end

function pop_saveinfo_OpeningFcn(hObject, eventdata, handles, varargin)
handles.output = hObject;
guidata(hObject, handles);


function varargout = pop_saveinfo_OutputFcn(hObject, eventdata, handles) 
varargout{1} = handles.output;


function edit1_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function pushbutton1_Callback(hObject, eventdata, handles)

H=guidata(ERP_tool);
infofile.filetype = get(H.popupmenu1,'Value');
infofile.path = get(H.edit1,'String');
infofile.elepath = get(H.edit6,'String');
infofile.rate    = get(H.edit7,'String');
infofile.time    = get(H.edit8,'String');
infofile.people  = get(H.edit2,'String');
infofile.type    = get(H.edit3,'String');
name = get(handles.edit1,'String');
if iscell(name)
    name=name{1};
end
path = [pwd,'\ERP_tool\teminfo\',name];
save(path,'infofile');
close(pop_saveinfo)
