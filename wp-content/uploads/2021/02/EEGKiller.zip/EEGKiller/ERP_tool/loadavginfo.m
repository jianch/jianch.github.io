function information = loadavginfo(path,people,type,handles)
i = 1;
j = 1;
filename = eval(changepath(path));

try
    [f,fid] = eeg_load_scan4_avg(filename);
    information.rate = f.header.rate;
    information.time = [round(f.header.displayxmin*1000),round(f.header.displayxmax*1000)];
    %information.time = [-200,400];
    INFO = get(handles,'String');
    INFO{length(INFO)+1} = ['�ɹ����������Ϣ'];
    set(handles,'String',INFO);
    drawnow
catch
    INFO = get(handles,'String');
    INFO{length(INFO)+1} = ['���������Ϣʧ�ܣ������ļ�·��'];
    set(handles,'String',INFO);
    drawnow
end