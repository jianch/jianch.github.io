function newdata = baseline(data,epoch,baseline)
index =(epoch.time>=baseline.timerange(1) & epoch.time<=baseline.timerange(2));
baselinedata = repmat(mean(data(index,:)),size(data,1),1);
newdata = data - baselinedata;
end