function [crest_new,latent_new]=pop_peak_det(AVG,time_range,channel,max_or_min,handles)
data = get(handles.OK,'UserData');
channel_value= get(handles.channel_sel_list,'Value');
[crest,latent]=findextremumpeak(AVG,time_range,channel,max_or_min);
det_range  = str2num(get(handles.edit18,'String'));
det_rangen = round(det_range*data.rate);
det_step   = str2num(get(handles.edit19,'String'));
det_stepn  = round(det_step*data.rate);
det_smooth = str2num(get(handles.edit20,'String'));
det_smoothn = round(det_smooth*data.rate);

latent_cha = str2num(get(handles.edit24,'String'));
peak_cha   = str2num(get(handles.edit25,'String'));
cha_lim    = str2num(get(handles.edit26,'String'));

det_num    = floor((data.time.max-data.time.min-det_range)/det_step)+1;
for ii=1:size(latent,1)
    for jj=1:size(latent,3)
        dix=find(latent(ii,:,jj)>(time_range(1)+det_smooth)&latent(ii,:,jj)<(time_range(2)-det_smooth));
        latent_avg(ii,jj)=mean(latent(ii,dix,jj));
    end
end

if max_or_min==1
    
    for n=1:length(channel)
        for i=1:length(data.people)
            for j=1:length(data.type)
                test = 1;
                peak = [];
                latentn = [];
                latent_p =  [];
                    for t=1:det_num
                        [a,b]=max(AVG(i,j).channel(1,channel_value(n)).data(((t-1)*det_stepn+1):((t-1)*det_stepn+det_rangen)));
                        if b>det_smoothn&b<=(det_rangen-det_smoothn);
                            peak(test)    = a;
                            latentn(test) = b+(t-1)*det_stepn;
                            test=test+1;
                        end
                    end
                    [peak_dan,peak_shunxu]=unique(peak,'first');
                    peak=peak(sort(peak_shunxu));
                    [latentn_dan,latentn_shunxu]=unique(latentn,'first');
                    latentn=latentn(sort(latentn_shunxu));                    
                    
                    latent_p = latentn/data.rate+data.time.min-1/data.rate;
                    [p,q]=sort(abs(latent_p-latent_avg(n,j)));
                    fir = q(1);
                    for ss = 2:length(q)
                        if abs(latent_p(q(ss))-latent(q(1)))>=cha_lim
                            sec = q(ss);
                            break;
                        end
                    end
                    if abs(latent_p(sec)-latent_p(fir))>=latent_cha
                        crest_new(n,i,j) = peak(fir);
                        latent_new(n,i,j) = latent_p(fir);
                    elseif abs(peak(sec)-peak(sec))>=peak_cha
                        crest_new(n,i,j) = max(peak(sec),peak(fir));
                        latent_new(n,i,j) = latent_p(find(peak==crest_new(n,i,j)));
                    else
                        crest_new(n,i,j) = peak(fir);
                        latent_new(n,i,j) = latent_p(fir);
                    end
            end
        end
    end
    
else
    
        
    for n=1:length(channel)
        for i=1:length(data.people)
            for j=1:length(data.type)
                test = 1;
                peak = [];
                latentn = [];
                latent_p =  [];
                    for t=1:det_num
                        [a,b]=min(AVG(i,j).channel(1,channel_value(n)).data(((t-1)*det_stepn+1):((t-1)*det_stepn+det_rangen)));
                        if b>det_smoothn&b<=(det_rangen-det_smoothn);
                            peak(test)    = a;
                            latentn(test) = b+(t-1)*det_stepn;
                            test=test+1;
                        end
                    end
                    [peak_dan,peak_shunxu]=unique(peak,'first');
                    peak=peak(sort(peak_shunxu));
                    [latentn_dan,latentn_shunxu]=unique(latentn,'first');
                    latentn=latentn(sort(latentn_shunxu));                    
                    
                    latent_p = latentn/data.rate+data.time.min-1/data.rate;
                    [p,q]=sort(abs(latent_p-latent_avg(n,j)));
                    fir = q(1);
                    for ss = 2:length(q)
                        if abs(latent_p(q(ss))-latent(q(1)))>=cha_lim
                            sec = q(ss);
                            break;
                        end
                    end
                    if abs(latent_p(sec)-latent_p(fir))>=latent_cha
                        crest_new(n,i,j) = peak(fir);
                        latent_new(n,i,j) = latent_p(fir);
                    elseif abs(peak(sec)-peak(sec))>=peak_cha
                        crest_new(n,i,j) = min(peak(sec),peak(fir));
                        latent_new(n,i,j) = latent_p(find(peak==crest_new(n,i,j)));
                    else
                        crest_new(n,i,j) = peak(fir);
                        latent_new(n,i,j) = latent_p(fir);
                    end
            end
        end
    end
end
                    
                    
                    
                    
                    
                    
                    
                    
                        
                    