function pop_topo_com(handles)
ele_path = get(handles.ele_path_edit,'String');
load(ele_path);
data       = pop_startdata(handles);
AVG        = get(handles.uipanel2,'UserData');
com_people = get(handles.type_popu,'Value');
time_t     = str2num(get(handles.timeser_edit,'String'));
time_n     = round((time_t/1000-data.time.min)*data.rate+1);


compare(1,1).title  = get(handles.edit8,'String');
compare(1,1).type   = str2num(get(handles.edit10,'String'));
for i=1:length(compare(1,1).type)
    tem(:,:,i) = [AVG(com_people,compare(1,1).type(i)).channel.data];
end
tem_mean = mean(tem,3);
compare(1,1).data   = tem_mean(time_n,:);

compare(1,2).title  = get(handles.edit9,'String');
compare(1,2).type   = str2num(get(handles.edit11,'String'));
for i=1:length(compare(1,2).type)
    tem(:,:,i) = [AVG(com_people,compare(1,2).type(i)).channel.data];
end
tem_mean = mean(tem,3);
compare(1,2).data   = tem_mean(time_n,:);
compare(1,3).title  = [compare(1,1).title,'-',compare(1,2).title];
compare(1,3).data   = compare(1,1).data - compare(1,2).data;

% max_peak     = max(abs([compare(1,1).data(:);compare(1,2).data(:)]));
% max_cha_peak = max(abs(compare(1,3).data(:)));
max_peak = 8;
max_cha_peak = 1;


H=figure;
set(H,'Position',[50 50 160*length(time_n) 160*3]);
for n=1:length(compare)
    uicontrol('Style', 'text','String',compare(1,n).title,'FontSize',12,'Position',[10,(3-n)*140+100,100,20],'FontWeight','bold');
end
    
    
for j=1:(3*length(time_n))
    subplot(3,length(time_n),j)
    comtype_num = floor((j-1)/length(time_n))+1;
    time_num    = mod(j-1,length(time_n))+1;
    switch comtype_num
        case {[1]}
            topoplot(compare(1,comtype_num).data(time_num,:),chanlocs,'maplimits',[-max_peak,max_peak],'plotrad',0.6,'headrad',0.6);
            title([num2str(time_t(time_num)),'ms']);
            if time_num == length(time_n)
                cbar(0,0,[-max_peak,max_peak]);
            end
        case {[2]}
            topoplot(compare(1,comtype_num).data(time_num,:),chanlocs,'maplimits',[-max_peak,max_peak],'plotrad',0.6,'headrad',0.6);
            if time_num == length(time_n)
                cbar(0,0,[-max_peak,max_peak]);
            end
        case {[3]}
            topoplot(compare(1,comtype_num).data(time_num,:),chanlocs,'maplimits',[-max_cha_peak,max_cha_peak],'plotrad',0.6,'headrad',0.6);
            if time_num == length(time_n)
                cbar(0,0,[-max_cha_peak,max_cha_peak]);
            end
        otherwise
    end
end




