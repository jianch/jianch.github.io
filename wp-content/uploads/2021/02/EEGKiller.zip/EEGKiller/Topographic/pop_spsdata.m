function pop_spsdata(A,s,handles)


type_name = get(handles.edit28,'String');
if ~iscell(type_name)
    type_name = cellstr(type_name);
end
channel_name = get(handles.popupmenu3,'String');
pathway  = get(handles.path,'String');
pathway  = pathway(1:regexp(get(handles.path,'String'),'people\')-1);
path     = uigetdir(pathway,'���浼�������ݵ�Ŀ¼�ļ���');
% pathnew  = path;
filename = get(handles.edit31,'String');
nchannel=size(A,1);
ntype   =size(A,3);
totaldata=[];


for i = 1:nchannel
    totaldata=[totaldata,reshapedata(A,i)];
end

totalrow=size(totaldata,2);
for j=1:totalrow
    p=mod(j-1,ntype)+1;
    q=floor((j-1)/ntype)+1;
    C{j}=[type_name{p},channel_name{q}];
end

spspath=[path,'\',filename,'-',s,'.dat'];

fid=fopen(spspath,'a+');
for ii=1:length(C)
    if ii~=length(C)
        fprintf(fid,'%s\t',C{ii});
    else
        fprintf(fid,'%s',C{ii});
    end
end
fprintf(fid,'\n');
fclose(fid);

fid=fopen(spspath,'a+');
for i=1:size(totaldata,1)
    for j=1:size(totaldata,2)
        if j~=size(totaldata,2)
            fprintf(fid,'%.3f\t',totaldata(i,j));
        else
            fprintf(fid,'%.3f',totaldata(i,j));
        end
    end
    fprintf(fid,'\n');
end
fclose(fid);