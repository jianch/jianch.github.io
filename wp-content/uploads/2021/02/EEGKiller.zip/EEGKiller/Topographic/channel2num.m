function A=channel2num(channel)
global data
for i=1:length(channel)
    A(i)=strmatch(channel{i},data.channel.name,'exact');
end