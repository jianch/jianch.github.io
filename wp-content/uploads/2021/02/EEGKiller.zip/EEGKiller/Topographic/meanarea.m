function areameans = meanarea(AVG,timerange,electrodes,baseline,rate,handles,handles2)

%2013-3-11

data = get(handles, 'UserData');

%% select sepecific eletrodes
ele = electrodes;
for j = 1:length(AVG)
    for k = 1:length(AVG(1,:))
        for i = 1:length(ele)
            sel = strcmp(lower(data.channel.name),lower(ele(i)));
            new(:,i) = AVG(j,k).channel(sel).data;
        end
        newdata{j,k} = new;
    end
end
newdata;
%% time range
if ~isempty(timerange)
    time1 = timerange(1)/(1000/rate)+baseline/(1000/rate)+1;
    time2 = timerange(2)/(1000/rate)+baseline/(1000/rate)+1;
else
    set(handles2,'String','ʱ�䷶Χδ��д')
end
    


for j = 1:length(newdata)
    for k = 1:length(newdata(1,:))
        seldata{j,k} = newdata{j,k}(time1:time2,:);
    end
end
%% areamean
for j = 1:length(seldata)
    for k = 1:length(seldata(1,:))
        areameans(j,k) = mean(mean(seldata{j,k}));
    end
end

save areamean.dat areameans -ascii

%%
set(handles2,'String','����ƽ�������ɹ�')

