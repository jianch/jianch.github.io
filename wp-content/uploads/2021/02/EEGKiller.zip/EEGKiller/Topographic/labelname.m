function labelname(avgname)


% load avg file
[f,fid]  = eeg_load_scan4_avg(avgname);

for i = 1:length(f.data)
    labelname{i} = char(f.electloc(1,i).lab)';
end

labelname = deblank(labelname');

save labelname labelname