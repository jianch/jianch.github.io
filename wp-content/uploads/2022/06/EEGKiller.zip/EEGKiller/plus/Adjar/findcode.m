function result=findcode(code,RT,cuecode,targetcode)
global data
j=1;
timeblock=[];
for i=1:(length(code)-1)
    test=length(find(cuecode==code(i)))&length(find(targetcode==code(i+1)));
    if test==1
        timeblock(j)=RT(i+1)-RT(i);
        j=j+1;
    end
end
timeblock=round(timeblock*1000)/1000;
timepoint=(data.relation.randtime.onset(1)+data.delay):(1/data.samplingrate):(data.relation.randtime.onset(2)+data.delay);
result=hist(timeblock,timepoint);