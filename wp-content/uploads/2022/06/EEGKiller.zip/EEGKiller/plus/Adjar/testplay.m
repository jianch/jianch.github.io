function testplay()
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
t=(-200:2:1000)';                     
distribute=rand(1,101);
%distribute=ones(1,101);
%distribute=zeros(1,101);
%distribute([1,26,86,12,70,32,65])=[1;1;1;1;1;1;1];
distribute=distribute/sum(distribute);
disnum=length(distribute);
range=[250,350];
bound=[0,length(t),-8,8];
%x11=1./(((t-80)./50).^2+0.5);        
%x21=-1./(((t-200)./100).^2+0.3);     
%x31=1./(((t-370)./150).^2+0.2);      
%x41=-atan((t-600)./100)-pi/2;        
%x51=sin(t.^2./90000)./2;             
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
wave_cue_org=[testplay_prowave(t),testplay_prowave(t)];
wave_target_org=[testplay_prowave(t),testplay_prowave(t)];
%wave_cue_org=[t>=0,t>=0];
%wave_target_org=[t>=0,t>=0];

effect_cue=arrayconv(distribute,wave_target_org);
effect_target=arrayconv(fliplr(distribute),wave_cue_org);   %
wave_cue=[wave_cue_org(1:(range(1)-1),:)   ;  (wave_cue_org(range(1):end,:)   +    effect_cue(1:size(wave_cue_org(range(1):end,:),1),:))];
wave_target=[ (effect_target(range(2):end,:)+ wave_target_org(1:size(effect_target(range(2):end,:),1),:));  wave_target_org( (size(effect_target(range(2):end,:),1)+1):end,:)];
n=-t(1)/2;
wave_target=[wave_target(:,1)-mean(wave_target(1:n,1)),wave_target(:,2)-mean(wave_target(1:n,2))];

%%%%%%%%%%%%%%%%%%
subplot(2,2,1)
plot(wave_cue_org);
axis(bound)    
subplot(2,2,2)
plot(wave_cue);
axis(bound)    
subplot(2,2,3)
plot(wave_target_org);
axis(bound)    
subplot(2,2,4)
plot(wave_target);
axis(bound)   
pause
%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
iterate_num=2;

for iter=1:iterate_num
    effect_cue=arrayconv(distribute,wave_target);
    wave_cue=[wave_cue(1:(range(1)-1),:)   ;  (wave_cue(range(1):end,:)   -    effect_cue(1:size(wave_cue(range(1):end,:),1),:))];
    effect_target=arrayconv(fliplr(distribute),wave_cue);
    wave_target=[ -effect_target(range(2):end,:)+ wave_target(1:size(effect_target(range(2):end,:),1),:);  wave_target( (size(effect_target(range(2):end,:),1)+1):end,:)];
    wave_target=[wave_target(:,1)-mean(wave_target(1:n,1)),wave_target(:,2)-mean(wave_target(1:n,2))];
    subplot(2,2,1)
    plot(wave_cue_org);
    axis(bound)      
    subplot(2,2,2)
    plot(wave_cue);
    axis(bound)   
    subplot(2,2,3)
    plot(wave_target_org);
    axis(bound)    
    subplot(2,2,4)
    plot(wave_target);
    axis(bound)  
    pause
end
close all