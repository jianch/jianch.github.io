function [subsequent,previous]=test()
global data;
data=installdata();
iterate_num=7;
code=reshape([5*ones(1,50);6*ones(1,50)],100,1);
RT(1)=0;
for i=2:100
    if mod(i,2)==0
        RT(i)=RT(i-1)+0.3+randint(1,1,[1,100])*0.002;
    else
        RT(i)=RT(i-1)+1;
    end
end
RT=RT';
t=0:2:1200;
cue_orgwave=sin(log(2.*t.^4+t.^3+t.^2+3.*t+1000000))+sin(exp(t./500));
target_orgwave=sin(log(t.^5+t.^4+t.^3+t.^2+t.^1+10000))+cos(log(t+1000));
WAVE=zeros(fix(RT(end)*500+length(t)+1),1);
for i=1:100
    if code(i)==5
        WAVE(round((RT(i)*500+1)):round((RT(i)*500+length(t))),1)=WAVE(round((RT(i)*500+1)):round((RT(i)*500+length(t))),1)+cue_orgwave';
    else
        WAVE(round((RT(i)*500+1)):round((RT(i)*500+length(t))),1)=WAVE(round((RT(i)*500+1)):round((RT(i)*500+length(t))),1)+target_orgwave';
    end
end
cue_wave=zeros(length(cue_orgwave),1);
target_wave=zeros(length(cue_orgwave),1);
for j=1:50
    cue_wave=cue_wave+WAVE(round(RT(2*j-1)*500+1):round(RT(2*j-1)*500+length(t)),1);
    target_wave=target_wave+WAVE(round(RT(2*j)*500+1):round(RT(2*j)*500+length(t)),1);
end
cue_wave=cue_wave/50;
target_wave=target_wave/50;

%plot(cue_wave)
%hold on
%plot(target_wave,'k')
%hold off
[subsequent,previous]=distribution(code,RT);
for iter=1:iterate_num
        cue_wave = updatecue(cue_wave,target_wave,subsequent);
        target_wave=updatetarget(cue_wave,target_wave,previous);
end
