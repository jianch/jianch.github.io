function display_eegdata(cue_data_org,target_data_org,cue_data,target_data)
global displaydata
global data
%%%%%%%%%%display cue_data
for i=1:length(data.cue.name)
    figure
    Fig1 = subplot(2,1,1);
    titles.title=['original cuewave','-',data.cue.name{i}];
    eeg_plot(displaydata.time,reshapedata(cue_data_org(:,:,displaydata.channel),i),displaydata.range,[],[],titles);
    
    
    Fig2 = subplot(2,1,2);
    titles.title=['adjar cuewave','-',data.cue.name{i}];
    eeg_plot(displaydata.time,reshapedata(cue_data(:,:,displaydata.channel),i),displaydata.range,[],[],titles);
end
%%%%%%%%%display target_data
for i=1:length(data.target.name)
    figure
    Fig1 = subplot(2,1,1);
    titles.title=['original targetwave','-',data.target.name{i}];
    eeg_plot(displaydata.time,reshapedata(target_data_org(:,:,displaydata.channel),i),displaydata.range,[],[],titles);
    
    
    Fig2 = subplot(2,1,2);
    titles.title=['adjar targetwave','-',data.target.name{i}];
    eeg_plot(displaydata.time,reshapedata(target_data(:,:,displaydata.channel),i),displaydata.range,[],[],titles);
end