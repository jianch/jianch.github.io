function save_data(cue_wave,target_wave,p)
global data
global person
global path
for i=1:length(data.cue.name)
    filename=[path,person{p},'-',data.cue.name{i},'.avg'];
    [f,fid]=eeg_load_scan4_avg(filename);
    baseline = repmat([f.electloc.baseline],[f.header.pnts],1);
    calibration = repmat([f.electloc.calib],[f.header.pnts],1);
    n = repmat([f.electloc.n],[f.header.pnts],1);
    wave=reshapedata(cue_wave,i).*n./calibration+baseline;
    for j=1:f.header.nchannels
        f.data(1,j).samples=wave(:,j);
    end
    filename_new=[path,person{p},'-adjar-',data.cue.name{i},'.avg'];
    eeg_write_scan4_avg(f,filename_new)
    clear f
end

for i=1:length(data.target.name)
    filename=[path,person{p},'-',data.target.name{i},'.avg'];
    [f,fid]=eeg_load_scan4_avg(filename);
    baseline = repmat([f.electloc.baseline],[f.header.pnts],1);
    calibration = repmat([f.electloc.calib],[f.header.pnts],1);
    n = repmat([f.electloc.n],[f.header.pnts],1);
    wave=reshapedata(target_wave,i).*n./calibration+baseline;
    for j=1:f.header.nchannels
        f.data(1,j).samples=wave(:,j);
    end
    filename_new=[path,person{p},'-adjar-',data.target.name{i},'.avg'];
    eeg_write_scan4_avg(f,filename_new)
end