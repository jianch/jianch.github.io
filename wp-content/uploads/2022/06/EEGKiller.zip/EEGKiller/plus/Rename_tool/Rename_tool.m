function varargout = Rename_tool(varargin)
% RENAME_TOOL M-file for Rename_tool.fig
%      RENAME_TOOL, by itself, creates a new RENAME_TOOL or raises the existing
%      singleton*.
%
%      H = RENAME_TOOL returns the handle to a new RENAME_TOOL or the handle to
%      the existing singleton*.
%
%      RENAME_TOOL('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in RENAME_TOOL.M with the given input arguments.
%
%      RENAME_TOOL('Property','Value',...) creates a new RENAME_TOOL or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Rename_tool_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Rename_tool_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Rename_tool

% Last Modified by GUIDE v2.5 25-Nov-2012 14:19:44

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Rename_tool_OpeningFcn, ...
                   'gui_OutputFcn',  @Rename_tool_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Rename_tool is made visible.
function Rename_tool_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Rename_tool (see VARARGIN)

% Choose default command line output for Rename_tool
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Rename_tool wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Rename_tool_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function pathshow_Callback(hObject, eventdata, handles)
% hObject    handle to pathshow (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of pathshow as text
%        str2double(get(hObject,'String')) returns contents of pathshow as a double

% �ֶ�����Ŀ¼
path = get(hObject, 'String');

if(7==exist(path,'dir')),   %���Ŀ¼������
    filename = dir(path);
    filename = {filename(3:end).name};
    set(handles.oldnamebox,'String',filename)
    % Updated handles structure
    guidata(hObject, handles);
else
    uiwait(errordlg('Ŀ¼�����ڣ�','����'));    
    set(hObject, 'String', '��������ȷ��·��');  
    return;
end


% --- Executes during object creation, after setting all properties.
function pathshow_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pathshow (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close;
%cd(D:\MATLAB7\matlab x64\workspace\test)
Genname;


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)  %ȷ���޸��ļ�������ִ���޸�

part = get(handles.popmenu,'Userdata');%��ȡ�ṹ��
s    = '';

for i = 1:length(get(handles.oldnamebox2,'String'));
    for j = 1:length(part);
        m = length(part(j).String);
        %part(j).String
        n = part(j).Num;
        p = mod(ceil((i-0.5)/n)-1,m)+1;        %�����1��2�ķ�������Ϊp
       
        s = [s,part(j).String{p}];
    end
    newname{i} = s;
    %newname = strcat(newname,'.jpg')
    s = '';
end

%����Ҫ����Ƿ����غϵ��ļ���
if length(newname)-length(unique(newname))
    uiwait(errordlg('�ļ������ص������������','����'));
return
end


    


aa = pwd;
cd(get(handles.pathshow,'String'));
name1 = get(handles.oldnamebox2,'String');
name2 = newname';
for k = 1:length(get(handles.oldnamebox2,'String'))
    name3 = name1{k};
    bb = regexp(name3,'\.');
    cc = name3(bb(end):end);
    name4 = [name2{k},cc]; 
    %name2{k}      
    %mmmm=['rename ' name3 ' ' name4]
    %system(['rename ',name3,' ',name4]);
    movefile(name3,name4);
end
uiwait(msgbox('�����ɹ���','��','none','modal'));
cd(aa);
%name1 = get(handles.oldnamebox2,'String');
%name2 = newname';
%for k = 1:length(get(handles.oldnamebox2,'String'))
%    name3 = name1{k};
%    bb = regexp(name3,'\.');
%    cc = name3(bb(end):end)
%    name4{k} = strcat(name2{k},cc)
    
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close;


% --- Executes on button press in radiobutton1.
function radiobutton1_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton1


% --- Executes on button press in radiobutton2.
function radiobutton2_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton2


% --- Executes on button press in getpath.
function getpath_Callback(hObject, eventdata, handles)
% hObject    handle to getpath (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[path] = uigetdir('','ѡ��Ŀ���ļ���');
set(handles.pathshow,'String',path);
%get filenames
filename = dir(path);
filename = {filename(3:end).name};
set(handles.oldnamebox,'String',filename);


% --- Executes on selection change in oldnamebox2.
function oldnamebox2_Callback(hObject, eventdata, handles)
% hObject    handle to oldnamebox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns oldnamebox2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from oldnamebox2


% --- Executes during object creation, after setting all properties.
function oldnamebox2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to oldnamebox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in newnamebox.
function newnamebox_Callback(hObject, eventdata, handles)
% hObject    handle to newnamebox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns newnamebox contents as cell array
%        contents{get(hObject,'Value')} returns selected item from newnamebox


% --- Executes during object creation, after setting all properties.
function newnamebox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to newnamebox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1


% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over getpath.
function getpath_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to getpath (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function edit5_Callback(hObject, eventdata, handles)
part = get(handles.popmenu,'UserData');    %��userdata��ȡ��part���Ӷ����Զ�����и���
n = get(handles.popmenu,'Value');          %�õ��м���part
part(n).String = get(hObject,'String');    %��edit5�������ֵ����part��string��
if ~iscell(part(n).String)                 %�ж�part��string�Ƿ�Ϊ�գ����Ϊ�գ���Ҳת��Ϊ�ַ�
    part(n).String = cellstr(part(n).String);
end
set(handles.popmenu,'Userdata',part);      %���޸ĺ��part��ֵ����userdata 

% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit5 as text
%        str2double(get(hObject,'String')) returns contents of edit5 as a double


% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit6_Callback(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit6 as text
%        str2double(get(hObject,'String')) returns contents of edit6 as a double


% --- Executes during object creation, after setting all properties.
function edit6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit7_Callback(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit7 as text
%        str2double(get(hObject,'String')) returns contents of edit7 as a double


% --- Executes during object creation, after setting all properties.
function edit7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit8_Callback(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit8 as text
%        str2double(get(hObject,'String')) returns contents of edit8 as a double


% --- Executes during object creation, after setting all properties.
function edit8_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit9_Callback(hObject, eventdata, handles)
part = get(handles.popmenu,'UserData');
n = get(handles.popmenu,'Value');
part(n).Num = str2num(get(hObject,'String'));
set(handles.popmenu,'Userdata',part);

% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit9 as text
%        str2double(get(hObject,'String')) returns contents of edit9 as a double


% --- Executes during object creation, after setting all properties.
function edit9_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit10_Callback(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit10 as text
%        str2double(get(hObject,'String')) returns contents of edit10 as a double


% --- Executes during object creation, after setting all properties.
function edit10_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit11_Callback(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit11 as text
%        str2double(get(hObject,'String')) returns contents of edit11 as a double


% --- Executes during object creation, after setting all properties.
function edit11_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit12_Callback(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit12 as text
%        str2double(get(hObject,'String')) returns contents of edit12 as a double


% --- Executes during object creation, after setting all properties.
function edit12_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)  %clear���ܣ��������������
set(handles.popmenu,'Userdata',{});
set(handles.edit16,'String','1');
set(handles.popmenu,'String','part1','Value',1);
set(handles.edit5,'String','');
set(handles.edit9,'String','1');

%get(handles.popmenu,'Userdata')
%get(handles.edit16,'String')
%get(handles.popmenu,'String')
%get(handles.edit5,'String')
%get(handles.edit9,'String')

% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)   %Ԥ���������������ִ����������
part = get(handles.popmenu,'Userdata');%��ȡ�ṹ��
s    = '';

for i = 1:length(get(handles.oldnamebox2,'String'));
    for j = 1:length(part);
        m = length(part(j).String);
        %part(j).String
        n = part(j).Num;
        p = mod(ceil((i-0.5)/n)-1,m)+1;        %�����1��2�ķ�������Ϊp
        %p
        %q = part(j).String{p};
        %q
        s = [s,part(j).String{p}];
    end
    newname{i} = s;
    newname;
    s = '';
end


if length(newname)-length(unique(newname))
    uiwait(errordlg('�ļ������ص������������','����'));
%return
end



name1 = get(handles.oldnamebox2,'String');
name2 = newname';
for k = 1:length(get(handles.oldnamebox2,'String'))
    name3 = name1{k};
    bb = regexp(name3,'\.');
    cc = name3(bb(end):end);
    name4{k} = strcat(name2{k},cc);
end


set(handles.newnamebox,'String',name4); 
        
        



%oldname = get(handles.oldnamebox2,'Sting');

%for i = 1:get(handles.edit16,'String')
    



% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function edit13_Callback(hObject, eventdata, handles)

str13 = strcat(get(handles.oldnamebox,'String'));
%disp(str13);
str133 = strcat(get(hObject,'String'));
%disp(str133);

str1333 = regexp(str13,str133);
%disp(str1333);

a13=[];
s=1;
for j = 1:length(str13);
   if length(str1333{j});
       a13(s)=j;
       s=s+1;
   else
   end
end
set(handles.oldnamebox,'Value',a13)

selestr13 = str13(get(handles.oldnamebox,'Value'));
set(handles.oldnamebox2,'String',selestr13);


% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit13 as text
%        str2double(get(hObject,'String')) returns contents of edit13 as a double


% --- Executes during object creation, after setting all properties.



function edit13_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in oldnamebox.
function oldnamebox_Callback(hObject, eventdata, handles)
% hObject    handle to oldnamebox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns oldnamebox contents as cell array
%        contents{get(hObject,'Value')} returns selected item from oldnamebox


% --- Executes during object creation, after setting all properties.
function oldnamebox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to oldnamebox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in checkbox1.
function checkbox1_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox1


% --- Executes on button press in checkbox2.
function checkbox2_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox2



function edit14_Callback(hObject, eventdata, handles)

%len14 = get(hObject,'String');
%len144 = [length(get(handles.oldnamebox,'String'))];
%for k = 1:length(get(handels.oldnamebox,'String'));
 %   if len144[i] == len14;
  %      a14 = len
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit14 as text
%        str2double(get(hObject,'String')) returns contents of edit14 as a double


% --- Executes during object creation, after setting all properties.
function edit14_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in checkbox3.
function checkbox3_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox3



function edit15_Callback(hObject, eventdata, handles)
% hObject    handle to edit15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit15 as text
%        str2double(get(hObject,'String')) returns contents of edit15 as a double


% --- Executes during object creation, after setting all properties.
function edit15_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%disp(get(handles.oldnamebox,'Value'))
totalstr = get(handles.oldnamebox,'String');
selestr = totalstr(get(handles.oldnamebox,'Value'));
set(handles.oldnamebox2,'String',selestr);


% --- Executes on selection change in popmenu.
function popmenu_Callback(hObject, eventdata, handles)

n = get(hObject,'Value');
part = get(hObject,'Userdata');
%part(n).String
if isempty(part(n).String)
    set(handles.edit5,'String',{''});
else
    set(handles.edit5,'String',part(n).String);
end
set(handles.edit9,'String',num2str(part(n).Num));


% hObject    handle to popmenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popmenu contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popmenu


% --- Executes during object creation, after setting all properties.
function popmenu_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popmenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit16_Callback(hObject, eventdata, handles)
a = str2num(get(hObject,'String'));
cell16 = {};
cell166 = {};
%s=1;
for i = 1:a;
    cell16{i} = ['Part',num2str(i)];
    %cell1666{s} = cell16{i};
    %s=s+1;
    part(i).String = {};
    part(i).Num    = [1];
end
set(handles.popmenu,'String',cell16);
set(handles.popmenu,'Userdata',part);



% hObject    handle to edit16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit16 as text
%        str2double(get(hObject,'String')) returns contents of edit16 as a double


% --- Executes during object creation, after setting all properties.
function edit16_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton8.
function pushbutton8_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% �����ı���Ϣ�������ո��Ե��ʵ����оࡣ
helpMsg = {'1. ѡ����Ҫ�������ļ����ڵ��ļ���;     ';
           '                                                    ';
           '2. �����ض��ַ����������ļ����а����������ַ��������Enter�� ';
           '     ���磺����s��Enter�����ֶ�ѡ�����еĶ�Ӧ�ļ�����ѡ����ļ�������      ';
           '     Ҳ����ʹ��ͨ����� �� .���Դ�������һ���ַ���\w ��������0-9,A-Z,a-z'
           '     ���ַ���\W ��������\w֮��ʣ�µ��ַ���\w��\W����Խ���*(�˺���0������'
           '     ���ַ�)��+���˺���һ�����ϵ��ַ�����{m,n}���˺���m��n���ַ���'
           '     ���磬��Ҫѡ��ǰ������ĸ��DSC�����ĸ���ĸΪ�����ַ������������ַ�Ϊ04��'
           '     �˺���1�������ַ��ģ��ļ�������JPG(������Ҫ���ִ�Сд)���ļ���������'
           '    ��DSC.04\w+.JPG��'
           '                                                    ';
           '3.    ';
           '                                                    ';
           '4.  ';
           '               ';
           '                                                    ';
           '5.    ';
           
           };
uiwait(msgbox(helpMsg,'������Ϣ','none','modal'));


% --- Executes on button press in pushbutton9.
function pushbutton9_Callback(hObject, eventdata, handles)      %�޳���ѡ�ļ�����һ�����߶��

a = get(handles.oldnamebox2,'Value');
b = get(handles.oldnamebox2,'String');
c = 1:length(b);
d = setdiff(c,a);
set(handles.oldnamebox2,'String',b(d),'Value',1);


% hObject    handle to pushbutton9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton10.
function pushbutton10_Callback(hObject, eventdata, handles)

helpMsg = {'1. ���߿���ʵ��ʮ������ѡȡ�ļ��Ĳ������������һЩ��ʾ��;     ';
           '                                                    ';
           '2. �����ض��ַ����������ļ����а����������ַ��������Enter�� ';
           '     ���磺����s��Enter�����ֶ�ѡ�����еĶ�Ӧ�ļ�����ѡ����ļ�������      ';
           '     Ҳ����ʹ��ͨ����� �� .���Դ�������һ���ַ���\w ��������0-9,A-Z,a-z'
           '     ���ַ���\W ��������\w֮��ʣ�µ��ַ���\w��\W����Խ���*(�˺���0������'
           '     ���ַ�)��+���˺���һ�����ϵ��ַ�����{m,n}���˺���m��n���ַ���'
           '     ���磬��Ҫѡ��ǰ������ĸ��DSC�����ĸ���ĸΪ�����ַ������������ַ�Ϊ04��'
           '     �˺���1�������ַ��ģ��ļ�������JPG(������Ҫ���ִ�Сд)���ļ���������'
           '    ��DSC.04\w+.JPG��'
                      
           '      '
           '      '
           };
uiwait(msgbox(helpMsg,'������Ϣ','none','modal'));

% hObject    handle to pushbutton10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function edit17_Callback(hObject, eventdata, handles)
% hObject    handle to edit17 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit17 as text
%        str2double(get(hObject,'String')) returns contents of edit17 as a double


% --- Executes during object creation, after setting all properties.
function edit17_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit17 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function figure1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
