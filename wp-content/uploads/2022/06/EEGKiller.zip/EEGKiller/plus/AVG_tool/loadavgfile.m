function wave = loadavgfile(filename)

[f,fid] = eeg_load_scan4_avg(filename);

ampData = [f.data.samples]; 
baseline = repmat([f.electloc.baseline],[f.header.pnts],1);
calibration = repmat([f.electloc.calib],[f.header.pnts],1);
n = repmat([f.electloc.n],[f.header.pnts],1);
wave = ( ampData - baseline ) .* calibration ./ n;
end