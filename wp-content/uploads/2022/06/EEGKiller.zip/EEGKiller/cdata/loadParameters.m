function varargout = loadParameters(varargin)
% LOADPARAMETERS M-file for loadParameters.fig
%      LOADPARAMETERS, by itself, creates a new LOADPARAMETERS or raises the existing
%      singleton*.
%
%      H = LOADPARAMETERS returns the handle to a new LOADPARAMETERS or the handle to
%      the existing singleton*.
%
%      LOADPARAMETERS('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in LOADPARAMETERS.M with the given input arguments.
%
%      LOADPARAMETERS('Property','Value',...) creates a new LOADPARAMETERS or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before loadParameters_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to loadParameters_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help loadParameters

% Last Modified by GUIDE v2.5 22-Nov-2012 23:42:17

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @loadParameters_OpeningFcn, ...
                   'gui_OutputFcn',  @loadParameters_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before loadParameters is made visible.
function loadParameters_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to loadParameters (see VARARGIN)

% Choose default command line output for loadParameters
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes loadParameters wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = loadParameters_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
H = guidata(eeganalyser);
file = get(handles.popupmenu1,'String');
if  ~(length(strmatch('empty',file,'exact')));
    name = file{get(handles.popupmenu1,'Value')};
    load([pwd,'\cdata\ParameterTemp\',name]);
    set(H.edit5,'String',parameter.filterlow);
    set(H.edit12,'String',parameter.filterhigh);
    set(H.edit6,'String',parameter.reference);
    set(H.edit7,'String',parameter.epochrangelow);
    set(H.edit11,'String',parameter.epochrangehigh);
    set(H.edit9,'String',parameter.rejection);
    set(H.edit10,'String',parameter.channels);
    set(H.edit8,'String',parameter.baselinelow);
    set(H.edit13,'String',parameter.baselinehigh);
    set(H.edit14,'String',parameter.strate);
    

    close(loadParameters);
else
    close(loadParameters);
end




% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close(loadParameters)

% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1


% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
s = dir([pwd,'\cdata\ParameterTemp']);
j=1;
for i = 1:length(s)
    if length(strfind(s(i,1).name,'.mat'));
        file{j,1} = s(i,1).name;
        j=j+1;
    end
end

if exist('file')
    set(hObject,'String',file);
else
    set(hObject,'String','empty');
end



% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
