function test
y=ecg(1000);
x=ecg(1000)'+0.5*randn(1000,1); %noisy waveform
x=x';
time = (1/100:1/100:10);
[smoothdata1] = eegfiltfft(x,100,0.1,3);
[smoothdata2] = eegfilt(x,100,0.1,3,0,32);
subplot(311)
plot(time,y,'r');
subplot(312)
plot(time,smoothdata1,'r');
hold on
plot(time,smoothdata2,'b');
plot(time,0,'k')
subplot(313)
plot(time,y-smoothdata1,'r');
hold on
plot(time,y-smoothdata2,'b');
plot(time,0,'k')