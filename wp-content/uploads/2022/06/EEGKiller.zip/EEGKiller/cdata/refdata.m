function newdata = refdata(data,ref,chan)
if strcmp(lower(ref.chan),'all')
    ref.chan = chan;
else
    ref.chan = regexp(upper(ref.chan),'\w*' , 'match');
end

[mm,channum]  = arrayinarray(ref.chan,chan);
meandata = repmat(mean(data(:,channum),2),1,length(chan));
newdata  = data - meandata;