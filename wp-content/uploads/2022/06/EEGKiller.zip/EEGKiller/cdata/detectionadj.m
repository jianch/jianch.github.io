function logic = detectionadj(data,ana,chan)
data = baseline(data,ana.epoch,ana.baseline);
if max(max(abs(data(:,arrayinarray(ana.adj.chan,chan)))))>=ana.adj.lim
    logic = true;
else
    logic = false;
end
