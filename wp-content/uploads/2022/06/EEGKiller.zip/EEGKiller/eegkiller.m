function varargout = EEGKiller(varargin)
% EEGKILLER M-file for EEGKiller.fig
%      EEGKILLER, by itself, creates a new EEGKILLER or raises the existing
%      singleton*.
%
%      H = EEGKILLER returns the handle to a new EEGKILLER or the handle to
%      the existing singleton*.
%
%      EEGKILLER('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in EEGKILLER.M with the given input arguments.
%
%      EEGKILLER('Property','Value',...) creates a new EEGKILLER or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before EEGKiller_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to EEGKiller_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help EEGKiller

% Last Modified by GUIDE v2.5 16-Jan-2013 11:18:13

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @EEGKiller_OpeningFcn, ...
                   'gui_OutputFcn',  @EEGKiller_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before EEGKiller is made visible.
function EEGKiller_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to EEGKiller (see VARARGIN)

% Choose default command line output for EEGKiller
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes EEGKiller wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = EEGKiller_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes during object creation, after setting all properties.
function axes1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
IM = imread('tsinghua.bmp');
image(IM,'Parent',hObject)
set(hObject,'Visible','off')
set(hObject,'Tag','axes1')
set(hObject,'CreateFcn',@(hObject,eventdata)eegkiller('axes1_CreateFcn',hObject,eventdata,guidata(hObject)))
% Hint: place code in OpeningFcn to populate axes1


% --- Executes during object creation, after setting all properties.
%function axes3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes1


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%close(handles.figure1);
%cd([pwd,'\cdata']);
eeganalyser



% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%filepath = [pwd,'\ERP_tool'];
%close(handles.figure1);
%cd([pwd,'\ERP_tool']);
ERP_tool



% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
dos('start http://www.tsinghua.edu.cn/publish/psy/index.html');
dos('start http://erplab.tap.cn/');


% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
dos(['start ',[pwd,'\documents\help.pdf']]);


% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
disp('   ');
disp('   ');
disp('   ');
disp('          tsinghua.erp@gmail.com')
disp('   ');
disp('   ');
disp('   ');
disp('Department of Psychology, Tsinghua University')
disp('   ');
disp('   ');
disp('   ');
close all


% --- Executes during object creation, after setting all properties.
function axes2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: place code in OpeningFcn to populate axes2
IM = imread('eegkiller.bmp');
image(IM,'Parent',hObject)
set(hObject,'Visible','off')
set(hObject,'Tag','axes2')
set(hObject,'CreateFcn',@(hObject,eventdata)eegkiller('axes2_CreateFcn',hObject,eventdata,guidata(hObject)))


% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1


% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
path = [pwd,'\plus'];
filename = dir(path);
filename = {filename(3:end).name};
filename = ['Toolbox';filename'];
set(hObject,'String',filename);



% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
closefun


% Hint: delete(hObject) closes the figure
delete(hObject);


% --- Executes during object creation, after setting all properties.
function figure1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
addpaths;


% --- Executes on button press in pushbutton8.
function pushbutton8_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Topo_Tool


% --- Executes when figure1 is resized.
function figure1_ResizeFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)





function closefun()


disp('-----------------------------------------------------------------------------');
disp('If you look forward to cooperation, please write to                      ----')
fprintf(1,'tsinghua.erp@gmail.com \n')
disp('To contact us, our address is                                            ----')
fprintf(1,'Room 311, Weiqing Hall, Tsinghua University,Haidian District, Beijing, China. \n')
disp('Postcode: 100084                                                         ---- ')
% disp('   ')
fprintf(1,'Department of Psychology, Tsinghua University\n')
disp('All Rights Reserved.                                                     ----')
disp('-----------------------------------------------------------------------------');
% disp('\(�����)>\(������)>\(�����)>\(��.��)>\( ^ _ ^ )>   ');
% disp('   ')
% disp(' (���n��)~*(�R���Q)~(������)~~(������)~(���n��)~*  ');
disp('   ')
disp('   ')
