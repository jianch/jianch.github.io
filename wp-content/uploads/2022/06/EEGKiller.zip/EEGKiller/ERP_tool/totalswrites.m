function s = totalswrites(handle1,handle2,handle3)
arry1   = get(handle1,'Value');
cells1 = get(handle1,'String');
s1 = swrites(arry1,cells1);

arry2   = get(handle2,'Value');
cells2 = get(handle2,'String');
s2 = swrites(arry2,cells2);

arry3   = get(handle3,'Value');
cells3 = get(handle3,'String');
s3 = swrites(arry3,cells3);

s = [s1,'_',s2,'_',s3];


function  s = swrites(arry,cells)
num = length(arry);
s = [];
for i = 1:num
    if i == 1
        s=[s,cells{arry(i)}];
    else
        s=[s,'|',cells{arry(i)}];
    end
end
s = ['{',s,'}'];