function pzhi = ttest(people,type,data,chanlocsname,INFOhandle,s);
%% ��s�ֽ�Ϊs1,s2�Լ�i_d
[s1,s2,i_d] = fenge(s);
%% �ֱ�s1��s2ת��������
cell1 = s2cell(s1,people);
for i = 1:length(cell1)
    s = cell1{i};
    totaldata1(:,i) = totalsreads(people,type,data,chanlocsname,INFOhandle,s);
end
cell2 = s2cell(s2,people);
for i = 1:length(cell2)
    s = cell2{i};
    totaldata2(:,i) = totalsreads(people,type,data,chanlocsname,INFOhandle,s);
end
%% T����
n = size(totaldata1,2);
switch i_d
    case 0
        for i = 1:size(totaldata1,1)
            u = mean(totaldata1(i,:));
            v = mean(totaldata2(i,:));
            pfh1 = sum((totaldata1(i,:)-u).^2);
            pfh2 = sum((totaldata2(i,:)-v).^2);
            t(i) = ((u-v)/sqrt(2/n))/sqrt((pfh1+pfh2)/(2*n-2));
            pzhi(i) = 2*(1-tcdf(abs(t(i)),2*n-2));
        end
    case 1
        for i = 1:size(totaldata1,1)
            pjz = mean(totaldata1(i,:)-totaldata2(i,:));
            pfh = sum((totaldata1(i,:)-totaldata2(i,:)).^2);
            t(i) = sqrt(n)*pjz/sqrt(pfh/(n-1));
            pzhi(i) = 2*(1-tcdf(abs(t(i)),2*n-2));
        end
    otherwise
end
            

    
function [s1,s2,i_d] = fenge(s)
s1_s = regexp(s,'ttest','end')+2;
douhao = regexp(s,',');
s1 = s(s1_s:(douhao(1)-1));
s2 = s((douhao(1)+1):(douhao(2)-1));
i_d = str2num(s(douhao(2)+1));


function str_new = transAVG(str,people_s)
while length(regexp(str,'AVG'))
    [a,b] = regexp(str,'AVG','start','end');
    str = [str(1:(a(1)-1)),people_s,str((b(1)+1):end)];
end
str_new = str;

function cells = s2cell(s,people)
for i = 1:(length(people)-1)
    cells{i} = transAVG(s,people{i});
end
