function varargout = pop_loadinfo(varargin)
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @pop_loadinfo_OpeningFcn, ...
                   'gui_OutputFcn',  @pop_loadinfo_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end

function pop_loadinfo_OpeningFcn(hObject, eventdata, handles, varargin)
handles.output = hObject;
guidata(hObject, handles);


function varargout = pop_loadinfo_OutputFcn(hObject, eventdata, handles) 
varargout{1} = handles.output;




function pushbutton1_Callback(hObject, eventdata, handles)
H=guidata(ERP_tool);
file = get(handles.popupmenu1,'String');
if ~(length(strmatch('empty',file,'exact')));
    name = file{get(handles.popupmenu1,'Value')};
    load([pwd,'/ERP_tool/teminfo/',name]);
    set(H.popupmenu1,'Value',infofile.filetype);
    set(H.edit1,'String',infofile.path);
    set(H.edit6,'String',infofile.elepath);
    set(H.edit7,'String',infofile.rate);
    set(H.edit8,'String',infofile.time);
    set(H.edit2,'String',infofile.people);
    set(H.edit3,'String',infofile.type);
    close(pop_loadinfo);
else
    close(pop_loadinfo);
end

function popupmenu1_CreateFcn(hObject, eventdata, handles)
s = dir([pwd,'/ERP_tool/teminfo']);
j=1;
for i = 1:length(s)
    if length(strfind(s(i,1).name,'.mat'));
        file{j,1} = s(i,1).name;
        j=j+1;
    end
end
if exist('file')
    set(hObject,'String',file);
else
    set(hObject,'String','empty');
end
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function popupmenu1_Callback(hObject, eventdata, handles)
