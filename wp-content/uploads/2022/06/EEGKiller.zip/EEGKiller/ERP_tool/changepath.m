function snew = changepath(s)
s1 = 'people';
s2 = 'type';
position1 = regexp(s,s1);
for i = 1:length(position1)
    s = [s(1:(position1(i)-1+(i-1)*7)),''',people{i},''',s((position1(i)+length(s1)+(i-1)*7):end)];
end
position2 = regexp(s,s2);
for i = 1:length(position2)
    s = [s(1:(position2(i)-1+(i-1)*7)),''',type{j},''',s((position2(i)+length(s2)+(i-1)*7):end)];
end
snew = ['[''',s,''']'];