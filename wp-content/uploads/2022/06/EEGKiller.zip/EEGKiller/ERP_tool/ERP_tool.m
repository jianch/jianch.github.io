function varargout = ERP_tool(varargin)
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ERP_tool_OpeningFcn, ...
                   'gui_OutputFcn',  @ERP_tool_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end

function ERP_tool_OpeningFcn(hObject, eventdata, handles, varargin)
handles.output = hObject;
guidata(hObject, handles);

function varargout = ERP_tool_OutputFcn(hObject, eventdata, handles) 
varargout{1} = handles.output;

%% ������
function CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function pushbutton1_Callback(hObject, eventdata, handles)
path   = get(handles.edit1,'String');
people = get(handles.edit2,'String');
type   = get(handles.edit3,'String');
switch get(handles.popupmenu1,'Value')
    case 1
        try 
            information = loadavginfo(path,people,type,handles.edit4);
        catch
            information = struct([]);
        end
        
        %try
            AVGdata  = loadavgdata(path,people,type,handles.edit4);
        %catch
        %    AVGdata  = {};
        %end
        
        try
            Chanlocs = loadavgchanlocs(path,people,type,handles.edit4);
        catch
            Chanlocs = struct([]);
        end
    otherwise
end

if ~isempty(information)
    set(handles.togglebutton1,'Value',1,'BackgroundColor',[0,1,0]);
    drawnow
    set(handles.togglebutton1,'UserData',information);
end
if ~isempty(AVGdata)
    set(handles.togglebutton2,'Value',1,'BackgroundColor',[0,1,0]);
    drawnow
    set(handles.togglebutton2,'UserData',AVGdata);
end
if ~isempty(Chanlocs)
    set(handles.togglebutton3,'Value',1,'BackgroundColor',[0,1,0]);
    drawnow
    set(handles.togglebutton3,'UserData',Chanlocs);
end

if ~isempty(information)&~isempty(AVGdata)&~isempty(Chanlocs)
    pop_figure
end

        
        

function popupmenu1_Callback(hObject, eventdata, handles)
switch get(hObject,'Value')
    case 1
        set(handles.text5,'Position',[23.6,16,17.6,1.538]);
        set(handles.text6,'Position',[49.6,16,17.6,1.538]);
        set(handles.edit2,'Position',[21.6,0.61,22,15]);
        set(handles.edit3,'Position',[47.6,0.61,22,15]);
        set([handles.text12,handles.text13,handles.text14,handles.edit6,handles.edit7,handles.edit8],'Visible','off');
    case 2
        set(handles.text5,'Position',[23.6,12,17.6,1.538]);
        set(handles.text6,'Position',[49.6,12,17.6,1.538]);
        set(handles.edit2,'Position',[21.6,0.61,22,11]);
        set(handles.edit3,'Position',[47.6,0.61,22,11]);
        set([handles.text12,handles.text13,handles.text14,handles.edit6,handles.edit7,handles.edit8],'Visible','on');
    otherwise
end

function pushbutton2_Callback(hObject, eventdata, handles)
pop_saveinfo();

function pushbutton3_Callback(hObject, eventdata, handles)
pop_loadinfo();


function pushbutton4_Callback(hObject, eventdata, handles)
set([handles.togglebutton1,handles.togglebutton2,handles.togglebutton3],'Value',0,'BackgroundColor',[1,0,0],'UserData',[]);
set(handles.edit4,'String','');


% --------------------------------------------------------------------
function Untitled_1_Callback(hObject, eventdata, handles)
switch (~isempty(get(handles.togglebutton1,'UserData')))&(~isempty(get(handles.togglebutton2,'UserData')))&(~isempty(get(handles.togglebutton3,'UserData')))
    case 1
        set(handles.Untitled_2,'Enable','on');
    otherwise
        set(handles.Untitled_2,'Enable','off');
end
% --------------------------------------------------------------------
function Untitled_2_Callback(hObject, eventdata, handles)
pop_figure;


% --------------------------------------------------------------------
function Untitled_3_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Untitled_4_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Genname;


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%cd('..');
% Hint: delete(hObject) closes the figure
delete(hObject);


% --- Executes during object creation, after setting all properties.
function axes1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
IM = imread('ERPtool.bmp');
image(IM,'Parent',hObject)
set(hObject,'Visible','off')
set(hObject,'Tag','axes1')
set(hObject,'CreateFcn',@(hObject,eventdata)ERP_tool('axes1_CreateFcn',hObject,eventdata,guidata(hObject)))

% Hint: place code in OpeningFcn to populate axes1
