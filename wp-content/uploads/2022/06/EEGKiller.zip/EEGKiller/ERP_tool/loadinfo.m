function loadinfo(VAR)
if nargin<1
    VAR= 'startup';
end 
switch VAR
    case 'startup'
        handle = ERP_tool;
        backcolor = get(handle,'Color');
        toolposition = get(handle,'Position');
        %% ��ҳ��
        fig = figure(...
        'Units','points',...
        'position',[toolposition(1)+toolposition(3)+5,toolposition(2)+toolposition(4)-100,200,100],...
        'name','Load information',...
        'numbertitle','off',...
        'menubar','none',...
        'color',backcolor);
       %% ����
        name = uicontrol(...
        'fontsize',13,...
        'units','points',...
        'style','text',...
        'string','�ļ���',...
        'position',[10,59,40,20],...
        'BackgroundColor',backcolor);
        %% ѡ���
        edit=uicontrol('units','points',...
        'style','popupmenu',...
        'string','',...
        'position',[60,60,120,20],...
        'BackgroundColor','white');
        s = dir([pwd,'/teminfo']);
        j=1;
        for i = 1:length(s)
            if length(strfind(s(i,1).name,'.mat'));
                file{j,1} = s(i,1).name;
                j=j+1;
            end
        end
        if exist('file')
            set(edit,'String',file);
        else
            set(edit,'String','empty');
        end
        set(handle,'UserData',[fig,edit]);
        %% ȷ��
        button = uicontrol(...
        'units','points',...
        'fontsize',10,...
        'style','pushbutton',...
        'string','ȷ��',...
        'position',[70,20,60,20],...
        'Callback','loadinfo(''set'')');
    case 'set'
        handle = ERP_tool;
        H=guidata(handle);
        point = get(handle,'UserData');
        set(handle,'UserData',[]);
        fig = point(1);
        edit= point(2);
        file = get(edit,'String');
        if ~(length(strmatch('empty',file,'exact')));
            name = file{get(edit,'Value')};
            load([pwd,'/teminfo/',name]);
            set(H.popupmenu1,'Value',infofile.filetype);
            set(H.edit1,'String',infofile.path);
            set(H.edit6,'String',infofile.elepath);
            set(H.edit7,'String',infofile.rate);
            set(H.edit8,'String',infofile.time);
            set(H.edit2,'String',infofile.people);
            set(H.edit3,'String',infofile.type);
            close(fig);
        else
            close(fig);
        end
    otherwise
end