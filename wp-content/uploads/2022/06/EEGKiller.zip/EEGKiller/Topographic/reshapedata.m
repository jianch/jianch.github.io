function reshapedata=reshapedata(wave,n)
reshapedata=reshape(wave(n,:,:),size(wave,2),size(wave,3));
