function [crest,latent]=findextremumpeak(AVG,time_range,channel,max_or_min)
global data
channel_value=channel2num(channel);
for n=1:length(channel)
    for i=1:length(data.people)
        for j=1:length(data.type)
            if max_or_min==1
                n1=round((time_range(1)-data.time.min)*data.rate+1);
                n2=round((time_range(2)-data.time.min)*data.rate+1);
                [crest(n,i,j),latent_bar(n,i,j)]=max(AVG(i,j).channel(1,channel_value(n)).data(n1:n2));
                latent(n,i,j)=(latent_bar(n,i,j)-1)/data.rate+time_range(1);
            else
                n1=round((time_range(1)-data.time.min)*data.rate+1);
                n2=round((time_range(2)-data.time.min)*data.rate+1);
                [crest(n,i,j),latent_bar(n,i,j)]=min(AVG(i,j).channel(1,channel_value(n)).data(n1:n2));
                latent(n,i,j)=(latent_bar(n,i,j)-1)/data.rate+time_range(1);   
            end
        end
    end
end
        