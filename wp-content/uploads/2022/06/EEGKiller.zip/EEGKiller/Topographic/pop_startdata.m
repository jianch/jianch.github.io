function data=pop_startdata(handles)
data.path   = get(handles.path,'String');
data.people = get(handles.people_name,'String');
data.type = get(handles.type,'String');
if ~iscell(data.type)
    data.type = cellstr(data.type);
end
data.name = get(handles.edit28,'String');
%data.ref    = get(handles.ref,'String');
%data.people={'gsc-02','gsc-03','gsc-06','gsc-07','gsc-08','gsc-09','gsc-10','gsc-11','gsc-12','gsc-13','gsc-14','gsc-15'};
%data.type={'lui','luv','ldi','ldv','rui','ruv','rdi','rdv'};
%data.name={'lui','luv','ldi','ldv','rui','ruv','rdi','rdv'};
%data.ref='all';



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
people = data.people;
type   = data.type;
i = 1; j = 1;
test_path = eval(changepath_new(data.path));
[f,fid]=eeg_load_scan4_avg(test_path);
data.channel.num=f.header.nchannels;
for i=1:data.channel.num
    data.channel.name{i}=char(f.electloc(1,i).lab(f.electloc(1,i).lab~=0))';
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
data.rate=f.header.rate;
data.time.pnts=f.header.pnts;
data.time.min=f.header.displayxmin;
data.time.max=f.header.displayxmax;
data.time.pro=data.time.min:(1/data.rate):data.time.max;
clear f fid

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%






