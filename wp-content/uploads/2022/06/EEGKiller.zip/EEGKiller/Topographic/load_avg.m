function AVG=load_avg(handles)
data=pop_startdata(handles);
people = data.people;
type   = data.type;
for i=1:length(data.people);
    for j=1:length(data.type);
%         filepath=[data.path,'\',data.people{i},'\',data.people{i},'-',data.type{j},'.avg'];
        filepath = eval(changepath_new(data.path));
        wave=loadavg(filepath);
        AVG(i,j).name=[data.people{i},'-',data.type{j}];
        for n=1:data.channel.num
            AVG(i,j).channel(1,n).name=data.channel.name{n};
            AVG(i,j).channel(1,n).data=wave(:,n);
        end
    end
end

for k=1:length(data.type)
    AVG(length(data.people)+1,k).name=['total-',data.type{k}];
    for n=1:data.channel.num
        AVG(length(data.people)+1,k).channel(1,n).name=data.channel.name{n};
        mean=zeros(data.time.pnts,1);
        for t=1:length(data.people)
            mean=mean+AVG(t,k).channel(1,n).data/length(data.people);
        end
        AVG(length(data.people)+1,k).channel(1,n).data=mean;
    end
end